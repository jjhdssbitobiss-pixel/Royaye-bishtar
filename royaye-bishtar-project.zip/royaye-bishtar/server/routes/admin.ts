import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {Router} from 'express';
import {
  isSafeLinkUrl,
  isSafeMediaUrl,
  requireAdmin,
  requireAuth,
  type AuthenticatedRequest,
} from '../auth.ts';
import {db, UPLOADS_DIR} from '../db.ts';

export const adminRouter = Router();

adminRouter.use(requireAuth, requireAdmin);

function makeSlug(text: string, prefix: string): string {
  const ascii = text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-');
  if (ascii.length >= 3) {
    return `${ascii}-${Date.now().toString(36).slice(-4)}`;
  }
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(2).toString('hex')}`;
}

adminRouter.get('/dashboard', (_req, res) => {
  const stats = {
    totalProducts: (db.prepare(`SELECT COUNT(*) as c FROM Products`).get() as {c: number}).c,
    activeProducts: (db.prepare(`SELECT COUNT(*) as c FROM Products WHERE is_active = 1`).get() as {c: number}).c,
    totalCategories: (db.prepare(`SELECT COUNT(*) as c FROM Categories`).get() as {c: number}).c,
    totalBrands: (db.prepare(`SELECT COUNT(*) as c FROM Brands`).get() as {c: number}).c,
    totalUsers: (
      db
        .prepare(`SELECT COUNT(*) as c FROM Users u JOIN Roles r ON r.id = u.role_id WHERE r.name = 'customer'`)
        .get() as {c: number}
    ).c,
    blockedUsers: (db.prepare(`SELECT COUNT(*) as c FROM Users WHERE is_blocked = 1`).get() as {c: number}).c,
    totalReviews: (db.prepare(`SELECT COUNT(*) as c FROM Reviews`).get() as {c: number}).c,
    pendingReviews: (db.prepare(`SELECT COUNT(*) as c FROM Reviews WHERE status = 'pending'`).get() as {c: number}).c,
    approvedReviews: (db.prepare(`SELECT COUNT(*) as c FROM Reviews WHERE status = 'approved'`).get() as {c: number}).c,
    totalRatings: (db.prepare(`SELECT COUNT(*) as c FROM Ratings`).get() as {c: number}).c,
    totalViews: (db.prepare(`SELECT COALESCE(SUM(view_count), 0) as c FROM Products`).get() as {c: number}).c,
  };

  const mostViewed = db
    .prepare(
      `SELECT p.id, p.name, p.view_count, p.price, p.stock_status,
              c.name AS category_name,
              COALESCE((SELECT ROUND(AVG(score), 2) FROM Ratings WHERE product_id = p.id), 0) AS avg_rating,
              (SELECT image_url FROM ProductImages WHERE product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS primary_image
       FROM Products p
       JOIN Categories c ON c.id = p.category_id
       ORDER BY p.view_count DESC
       LIMIT 5`
    )
    .all();

  const highestRated = db
    .prepare(
      `SELECT p.id, p.name, p.view_count, p.price,
              c.name AS category_name,
              COALESCE((SELECT ROUND(AVG(score), 2) FROM Ratings WHERE product_id = p.id), 0) AS avg_rating,
              (SELECT COUNT(*) FROM Ratings WHERE product_id = p.id) AS rating_count,
              (SELECT image_url FROM ProductImages WHERE product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS primary_image
       FROM Products p
       JOIN Categories c ON c.id = p.category_id
       ORDER BY avg_rating DESC, rating_count DESC, p.view_count DESC
       LIMIT 5`
    )
    .all();

  const recentPendingReviews = db
    .prepare(
      `SELECT rv.id, rv.title, rv.comment, rv.status, rv.created_at,
              u.full_name AS user_name, u.email AS user_email,
              p.name AS product_name, p.id AS product_id
       FROM Reviews rv
       JOIN Users u ON u.id = rv.user_id
       JOIN Products p ON p.id = rv.product_id
       WHERE rv.status = 'pending'
       ORDER BY rv.created_at DESC
       LIMIT 5`
    )
    .all();

  res.json({stats, mostViewed, highestRated, recentPendingReviews});
});

// --- Products Management ---
adminRouter.get('/products', (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const where = q ? `WHERE p.name LIKE ? OR p.sku LIKE ? OR c.name LIKE ?` : '';
  const params = q ? [`%${q}%`, `%${q}%`, `%${q}%`] : [];

  const products = db
    .prepare(
      `SELECT p.*, c.name AS category_name, b.name AS brand_name,
              (SELECT image_url FROM ProductImages WHERE product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS primary_image,
              COALESCE((SELECT ROUND(AVG(score), 2) FROM Ratings WHERE product_id = p.id), 0) AS avg_rating,
              (SELECT COUNT(*) FROM Ratings WHERE product_id = p.id) AS rating_count,
              (SELECT COUNT(*) FROM Reviews WHERE product_id = p.id) AS review_count
       FROM Products p
       JOIN Categories c ON c.id = p.category_id
       LEFT JOIN Brands b ON b.id = p.brand_id
       ${where}
       ORDER BY p.sort_order ASC, p.id DESC`
    )
    .all(...params);

  res.json({products});
});

adminRouter.get('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const product = db.prepare(`SELECT * FROM Products WHERE id = ?`).get(id);
  if (!product) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }
  const images = db
    .prepare(`SELECT * FROM ProductImages WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC, id ASC`)
    .all(id);
  const specifications = db
    .prepare(`SELECT * FROM ProductSpecifications WHERE product_id = ? ORDER BY sort_order ASC, id ASC`)
    .all(id);
  res.json({product, images, specifications});
});

interface ImageInput {
  image_url: string;
  alt_text?: string;
  is_primary?: boolean;
}

interface SpecInput {
  spec_key: string;
  spec_value: string;
}

function validateProductPayload(body: Record<string, unknown>) {
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const categoryId = Number(body.category_id);
  const brandId = body.brand_id ? Number(body.brand_id) : null;
  const sku = typeof body.sku === 'string' ? body.sku.trim() : null;
  const shortDescription = typeof body.short_description === 'string' ? body.short_description.trim() : '';
  const description = typeof body.description === 'string' ? body.description.trim() : '';
  const dimensions = typeof body.dimensions === 'string' ? body.dimensions.trim() : '';
  const material = typeof body.material === 'string' ? body.material.trim() : '';
  const features = typeof body.features === 'string' ? body.features.trim() : '';
  const price = Number(body.price);
  const stockStatus = typeof body.stock_status === 'string' ? body.stock_status : 'in_stock';
  const stockQuantity = body.stock_quantity !== undefined ? Number(body.stock_quantity) : 0;
  const isActive = body.is_active === false || body.is_active === 0 ? 0 : 1;
  const isFeatured = body.is_featured === true || body.is_featured === 1 ? 1 : 0;
  const sortOrder = body.sort_order !== undefined ? Number(body.sort_order) : 0;

  if (name.length < 2) return {error: 'نام محصول الزامی است.'};
  if (!Number.isInteger(categoryId) || categoryId <= 0) return {error: 'دسته‌بندی معتبر انتخاب کنید.'};
  if (description.length < 5) return {error: 'توضیحات کامل محصول الزامی است.'};
  if (Number.isNaN(price) || price < 0) return {error: 'قیمت محصول معتبر نیست.'};
  if (!['in_stock', 'low_stock', 'out_of_stock'].includes(stockStatus)) {
    return {error: 'وضعیت موجودی نامعتبر است.'};
  }

  const rawImages = Array.isArray(body.images) ? (body.images as ImageInput[]) : [];
  const images = rawImages
    .filter((img) => img && typeof img.image_url === 'string' && isSafeMediaUrl(img.image_url))
    .map((img, idx) => ({
      image_url: img.image_url.trim(),
      alt_text: typeof img.alt_text === 'string' && img.alt_text.trim() ? img.alt_text.trim() : name,
      is_primary: Boolean(img.is_primary) || idx === 0,
    }));

  if (images.length > 0 && !images.some((i) => i.is_primary)) {
    images[0].is_primary = true;
  }

  const rawSpecs = Array.isArray(body.specifications) ? (body.specifications as SpecInput[]) : [];
  const specifications = rawSpecs
    .filter(
      (s) =>
        s &&
        typeof s.spec_key === 'string' &&
        s.spec_key.trim() &&
        typeof s.spec_value === 'string' &&
        s.spec_value.trim()
    )
    .map((s) => ({
      spec_key: s.spec_key.trim(),
      spec_value: s.spec_value.trim(),
    }));

  return {
    data: {
      name,
      categoryId,
      brandId: brandId && !Number.isNaN(brandId) ? brandId : null,
      sku: sku || null,
      shortDescription,
      description,
      dimensions,
      material,
      features,
      price: Math.round(price),
      stockStatus,
      stockQuantity: Number.isNaN(stockQuantity) ? 0 : Math.max(0, Math.round(stockQuantity)),
      isActive,
      isFeatured,
      sortOrder: Number.isNaN(sortOrder) ? 0 : Math.round(sortOrder),
      images,
      specifications,
    },
  };
}

adminRouter.post('/products', (req, res) => {
  const parsed = validateProductPayload(req.body || {});
  if ('error' in parsed) {
    res.status(400).json({error: parsed.error});
    return;
  }
  const d = parsed.data;
  const slug = makeSlug(d.name, 'product');

  const createTx = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO Products (
          category_id, brand_id, name, slug, sku, short_description, description,
          dimensions, material, features, price, stock_status, stock_quantity,
          is_active, is_featured, sort_order
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        d.categoryId,
        d.brandId,
        d.name,
        slug,
        d.sku,
        d.shortDescription,
        d.description,
        d.dimensions,
        d.material,
        d.features,
        d.price,
        d.stockStatus,
        d.stockQuantity,
        d.isActive,
        d.isFeatured,
        d.sortOrder
      );

    const productId = Number(info.lastInsertRowid);
    const insImg = db.prepare(
      `INSERT INTO ProductImages (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, ?, ?)`
    );
    d.images.forEach((img, idx) => {
      insImg.run(productId, img.image_url, img.alt_text, img.is_primary ? 1 : 0, idx + 1);
    });

    const insSpec = db.prepare(
      `INSERT INTO ProductSpecifications (product_id, spec_key, spec_value, sort_order) VALUES (?, ?, ?, ?)`
    );
    d.specifications.forEach((sp, idx) => {
      insSpec.run(productId, sp.spec_key, sp.spec_value, idx + 1);
    });

    return productId;
  });

  const productId = createTx();
  res.status(201).json({id: productId});
});

adminRouter.put('/products/:id', (req, res) => {
  const productId = Number(req.params.id);
  const existing = db.prepare(`SELECT id FROM Products WHERE id = ?`).get(productId);
  if (!existing) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }

  const parsed = validateProductPayload(req.body || {});
  if ('error' in parsed) {
    res.status(400).json({error: parsed.error});
    return;
  }
  const d = parsed.data;

  const updateTx = db.transaction(() => {
    db.prepare(
      `UPDATE Products SET
        category_id = ?, brand_id = ?, name = ?, sku = ?, short_description = ?,
        description = ?, dimensions = ?, material = ?, features = ?, price = ?,
        stock_status = ?, stock_quantity = ?, is_active = ?, is_featured = ?,
        sort_order = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(
      d.categoryId,
      d.brandId,
      d.name,
      d.sku,
      d.shortDescription,
      d.description,
      d.dimensions,
      d.material,
      d.features,
      d.price,
      d.stockStatus,
      d.stockQuantity,
      d.isActive,
      d.isFeatured,
      d.sortOrder,
      productId
    );

    db.prepare(`DELETE FROM ProductImages WHERE product_id = ?`).run(productId);
    const insImg = db.prepare(
      `INSERT INTO ProductImages (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, ?, ?)`
    );
    d.images.forEach((img, idx) => {
      insImg.run(productId, img.image_url, img.alt_text, img.is_primary ? 1 : 0, idx + 1);
    });

    db.prepare(`DELETE FROM ProductSpecifications WHERE product_id = ?`).run(productId);
    const insSpec = db.prepare(
      `INSERT INTO ProductSpecifications (product_id, spec_key, spec_value, sort_order) VALUES (?, ?, ?, ?)`
    );
    d.specifications.forEach((sp, idx) => {
      insSpec.run(productId, sp.spec_key, sp.spec_value, idx + 1);
    });
  });

  updateTx();
  res.json({updated: true});
});

adminRouter.patch('/products/:id', (req, res) => {
  const productId = Number(req.params.id);
  const existing = db.prepare(`SELECT * FROM Products WHERE id = ?`).get(productId) as
    | Record<string, unknown>
    | undefined;
  if (!existing) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }

  const isActive =
    req.body.is_active !== undefined ? (req.body.is_active ? 1 : 0) : Number(existing.is_active);
  const isFeatured =
    req.body.is_featured !== undefined ? (req.body.is_featured ? 1 : 0) : Number(existing.is_featured);
  const sortOrder =
    req.body.sort_order !== undefined && !Number.isNaN(Number(req.body.sort_order))
      ? Number(req.body.sort_order)
      : Number(existing.sort_order);

  db.prepare(
    `UPDATE Products SET is_active = ?, is_featured = ?, sort_order = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(isActive, isFeatured, sortOrder, productId);

  res.json({updated: true});
});

adminRouter.delete('/products/:id', (req, res) => {
  const productId = Number(req.params.id);
  const info = db.prepare(`DELETE FROM Products WHERE id = ?`).run(productId);
  if (info.changes === 0) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }
  res.json({deleted: true});
});

// --- Categories Management ---
adminRouter.get('/categories', (_req, res) => {
  const categories = db
    .prepare(
      `SELECT c.*, p.name AS parent_name,
              (SELECT COUNT(*) FROM Products pr WHERE pr.category_id = c.id) AS product_count
       FROM Categories c
       LEFT JOIN Categories p ON p.id = c.parent_id
       ORDER BY COALESCE(c.parent_id, c.id), c.parent_id IS NOT NULL, c.sort_order ASC, c.id ASC`
    )
    .all();
  res.json({categories});
});

adminRouter.post('/categories', (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const parentId = req.body?.parent_id ? Number(req.body.parent_id) : null;
  const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
  const imageUrl = typeof req.body?.image_url === 'string' ? req.body.image_url.trim() : '';
  const sortOrder = req.body?.sort_order !== undefined ? Number(req.body.sort_order) : 0;
  const isActive = req.body?.is_active === false || req.body?.is_active === 0 ? 0 : 1;

  if (name.length < 2) {
    res.status(400).json({error: 'نام دسته‌بندی الزامی است.'});
    return;
  }
  if (imageUrl && !isSafeMediaUrl(imageUrl)) {
    res.status(400).json({error: 'آدرس تصویر دسته‌بندی نامعتبر است.'});
    return;
  }

  const slug = makeSlug(name, 'cat');
  const info = db
    .prepare(
      `INSERT INTO Categories (parent_id, name, slug, description, image_url, sort_order, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      parentId && !Number.isNaN(parentId) ? parentId : null,
      name,
      slug,
      description || null,
      imageUrl || null,
      Number.isNaN(sortOrder) ? 0 : sortOrder,
      isActive
    );

  res.status(201).json({id: Number(info.lastInsertRowid)});
});

adminRouter.put('/categories/:id', (req, res) => {
  const id = Number(req.params.id);
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const parentId = req.body?.parent_id ? Number(req.body.parent_id) : null;
  const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
  const imageUrl = typeof req.body?.image_url === 'string' ? req.body.image_url.trim() : '';
  const sortOrder = req.body?.sort_order !== undefined ? Number(req.body.sort_order) : 0;
  const isActive = req.body?.is_active === false || req.body?.is_active === 0 ? 0 : 1;

  if (name.length < 2) {
    res.status(400).json({error: 'نام دسته‌بندی الزامی است.'});
    return;
  }
  if (parentId === id) {
    res.status(400).json({error: 'یک دسته‌بندی نمی‌تواند والد خودش باشد.'});
    return;
  }
  if (imageUrl && !isSafeMediaUrl(imageUrl)) {
    res.status(400).json({error: 'آدرس تصویر دسته‌بندی نامعتبر است.'});
    return;
  }

  db.prepare(
    `UPDATE Categories SET parent_id = ?, name = ?, description = ?, image_url = ?, sort_order = ?, is_active = ? WHERE id = ?`
  ).run(
    parentId && !Number.isNaN(parentId) ? parentId : null,
    name,
    description || null,
    imageUrl || null,
    Number.isNaN(sortOrder) ? 0 : sortOrder,
    isActive,
    id
  );
  res.json({updated: true});
});

adminRouter.delete('/categories/:id', (req, res) => {
  const id = Number(req.params.id);
  const usedCount = (db.prepare(`SELECT COUNT(*) as c FROM Products WHERE category_id = ?`).get(id) as {c: number}).c;
  if (usedCount > 0) {
    res.status(409).json({
      error: `این دسته‌بندی دارای ${usedCount} محصول است. ابتدا محصولات آن را به دسته‌بندی دیگری منتقل کنید.`,
    });
    return;
  }
  db.prepare(`DELETE FROM Categories WHERE id = ?`).run(id);
  res.json({deleted: true});
});

// --- Brands Management ---
adminRouter.get('/brands', (_req, res) => {
  const brands = db
    .prepare(
      `SELECT b.*, (SELECT COUNT(*) FROM Products p WHERE p.brand_id = b.id) AS product_count
       FROM Brands b ORDER BY b.name ASC`
    )
    .all();
  res.json({brands});
});

adminRouter.post('/brands', (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const country = typeof req.body?.country === 'string' ? req.body.country.trim() : '';
  const description = typeof req.body?.description === 'string' ? req.body.description.trim() : '';
  if (name.length < 2) {
    res.status(400).json({error: 'نام برند الزامی است.'});
    return;
  }
  const slug = makeSlug(name, 'brand');
  try {
    const info = db
      .prepare(`INSERT INTO Brands (name, slug, country, description) VALUES (?, ?, ?, ?)`)
      .run(name, slug, country || null, description || null);
    res.status(201).json({id: Number(info.lastInsertRowid)});
  } catch {
    res.status(409).json({error: 'برندی با این نام قبلاً ثبت شده است.'});
  }
});

adminRouter.delete('/brands/:id', (req, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM Brands WHERE id = ?`).run(id);
  res.json({deleted: true});
});

// --- Reviews & Ratings Management ---
adminRouter.get('/reviews', (req, res) => {
  const status = typeof req.query.status === 'string' ? req.query.status : 'all';
  const where = ['pending', 'approved', 'rejected'].includes(status) ? `WHERE rv.status = ?` : '';
  const params = ['pending', 'approved', 'rejected'].includes(status) ? [status] : [];

  const reviews = db
    .prepare(
      `SELECT rv.*,
              u.full_name AS user_name, u.email AS user_email, u.is_blocked AS user_is_blocked,
              p.name AS product_name,
              rt.score AS user_rating
       FROM Reviews rv
       JOIN Users u ON u.id = rv.user_id
       JOIN Products p ON p.id = rv.product_id
       LEFT JOIN Ratings rt ON rt.product_id = rv.product_id AND rt.user_id = rv.user_id
       ${where}
       ORDER BY CASE rv.status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, rv.created_at DESC`
    )
    .all(...params);

  const ratingSummary = db
    .prepare(
      `SELECT p.id, p.name,
              COALESCE(ROUND(AVG(rt.score), 2), 0) AS avg_rating,
              COUNT(rt.id) AS rating_count,
              (SELECT COUNT(*) FROM Reviews rv WHERE rv.product_id = p.id) AS review_count
       FROM Products p
       LEFT JOIN Ratings rt ON rt.product_id = p.id
       GROUP BY p.id
       HAVING rating_count > 0 OR review_count > 0
       ORDER BY avg_rating DESC, rating_count DESC`
    )
    .all();

  res.json({reviews, ratingSummary});
});

adminRouter.patch('/reviews/:id/moderate', (req, res) => {
  const id = Number(req.params.id);
  const status = typeof req.body?.status === 'string' ? req.body.status : '';
  const adminNote = typeof req.body?.admin_note === 'string' ? req.body.admin_note.trim() : null;

  if (!['approved', 'rejected', 'pending'].includes(status)) {
    res.status(400).json({error: 'وضعیت بررسی نامعتبر است.'});
    return;
  }

  const info = db
    .prepare(`UPDATE Reviews SET status = ?, admin_note = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(status, adminNote || null, id);

  if (info.changes === 0) {
    res.status(404).json({error: 'نظر یافت نشد.'});
    return;
  }
  res.json({updated: true, status});
});

adminRouter.delete('/reviews/:id', (req, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM Reviews WHERE id = ?`).run(id);
  res.json({deleted: true});
});

// --- Users Management ---
adminRouter.get('/users', (_req, res) => {
  const users = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.city, u.is_blocked, u.created_at,
              r.name AS role_name, r.display_name AS role_display_name,
              (SELECT COUNT(*) FROM Reviews rv WHERE rv.user_id = u.id) AS review_count,
              (SELECT COUNT(*) FROM Ratings rt WHERE rt.user_id = u.id) AS rating_count
       FROM Users u
       JOIN Roles r ON r.id = u.role_id
       ORDER BY r.name ASC, u.created_at DESC`
    )
    .all();
  res.json({users});
});

adminRouter.get('/users/:id/activity', (req, res) => {
  const userId = Number(req.params.id);
  const user = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.city, u.is_blocked, u.created_at,
              r.name AS role_name, r.display_name AS role_display_name
       FROM Users u JOIN Roles r ON r.id = u.role_id WHERE u.id = ?`
    )
    .get(userId);
  if (!user) {
    res.status(404).json({error: 'کاربر یافت نشد.'});
    return;
  }
  const reviews = db
    .prepare(
      `SELECT rv.*, p.name AS product_name
       FROM Reviews rv JOIN Products p ON p.id = rv.product_id
       WHERE rv.user_id = ? ORDER BY rv.created_at DESC`
    )
    .all(userId);
  const ratings = db
    .prepare(
      `SELECT rt.*, p.name AS product_name
       FROM Ratings rt JOIN Products p ON p.id = rt.product_id
       WHERE rt.user_id = ? ORDER BY rt.updated_at DESC`
    )
    .all(userId);
  res.json({user, reviews, ratings});
});

adminRouter.patch('/users/:id/block', (req: AuthenticatedRequest, res) => {
  const userId = Number(req.params.id);
  if (userId === req.user!.id) {
    res.status(400).json({error: 'مدیر نمی‌تواند حساب خود را مسدود کند.'});
    return;
  }
  const target = db
    .prepare(
      `SELECT u.id, r.name AS role_name FROM Users u JOIN Roles r ON r.id = u.role_id WHERE u.id = ?`
    )
    .get(userId) as {id: number; role_name: string} | undefined;
  if (!target) {
    res.status(404).json({error: 'کاربر یافت نشد.'});
    return;
  }
  if (target.role_name === 'admin') {
    res.status(403).json({error: 'امکان مسدود کردن حساب مدیر وجود ندارد.'});
    return;
  }

  const isBlocked = req.body?.is_blocked ? 1 : 0;
  db.prepare(`UPDATE Users SET is_blocked = ?, updated_at = datetime('now') WHERE id = ?`).run(
    isBlocked,
    userId
  );
  res.json({updated: true, is_blocked: isBlocked});
});

// --- Banners Management ---
adminRouter.get('/banners', (_req, res) => {
  const banners = db.prepare(`SELECT * FROM Banners ORDER BY position ASC, sort_order ASC, id DESC`).all();
  res.json({banners});
});

adminRouter.post('/banners', (req, res) => {
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const subtitle = typeof req.body?.subtitle === 'string' ? req.body.subtitle.trim() : '';
  const imageUrl = typeof req.body?.image_url === 'string' ? req.body.image_url.trim() : '';
  const linkUrl = typeof req.body?.link_url === 'string' ? req.body.link_url.trim() : '';
  const buttonText = typeof req.body?.button_text === 'string' ? req.body.button_text.trim() : '';
  const position = req.body?.position === 'promo' ? 'promo' : 'hero';
  const sortOrder = req.body?.sort_order !== undefined ? Number(req.body.sort_order) : 0;
  const isActive = req.body?.is_active === false || req.body?.is_active === 0 ? 0 : 1;

  if (title.length < 2) {
    res.status(400).json({error: 'عنوان بنر الزامی است.'});
    return;
  }
  if (!isSafeMediaUrl(imageUrl)) {
    res.status(400).json({error: 'تصویر معتبر برای بنر انتخاب کنید.'});
    return;
  }
  if (linkUrl && !isSafeLinkUrl(linkUrl)) {
    res.status(400).json({error: 'لینک بنر نامعتبر است.'});
    return;
  }

  const info = db
    .prepare(
      `INSERT INTO Banners (title, subtitle, image_url, link_url, button_text, position, sort_order, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      title,
      subtitle || null,
      imageUrl,
      linkUrl || null,
      buttonText || null,
      position,
      Number.isNaN(sortOrder) ? 0 : sortOrder,
      isActive
    );

  res.status(201).json({id: Number(info.lastInsertRowid)});
});

adminRouter.put('/banners/:id', (req, res) => {
  const id = Number(req.params.id);
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const subtitle = typeof req.body?.subtitle === 'string' ? req.body.subtitle.trim() : '';
  const imageUrl = typeof req.body?.image_url === 'string' ? req.body.image_url.trim() : '';
  const linkUrl = typeof req.body?.link_url === 'string' ? req.body.link_url.trim() : '';
  const buttonText = typeof req.body?.button_text === 'string' ? req.body.button_text.trim() : '';
  const position = req.body?.position === 'promo' ? 'promo' : 'hero';
  const sortOrder = req.body?.sort_order !== undefined ? Number(req.body.sort_order) : 0;
  const isActive = req.body?.is_active === false || req.body?.is_active === 0 ? 0 : 1;

  if (title.length < 2) {
    res.status(400).json({error: 'عنوان بنر الزامی است.'});
    return;
  }
  if (!isSafeMediaUrl(imageUrl)) {
    res.status(400).json({error: 'آدرس تصویر بنر نامعتبر است.'});
    return;
  }
  if (linkUrl && !isSafeLinkUrl(linkUrl)) {
    res.status(400).json({error: 'لینک بنر نامعتبر است.'});
    return;
  }

  db.prepare(
    `UPDATE Banners SET title = ?, subtitle = ?, image_url = ?, link_url = ?, button_text = ?, position = ?, sort_order = ?, is_active = ? WHERE id = ?`
  ).run(
    title,
    subtitle || null,
    imageUrl,
    linkUrl || null,
    buttonText || null,
    position,
    Number.isNaN(sortOrder) ? 0 : sortOrder,
    isActive,
    id
  );
  res.json({updated: true});
});

adminRouter.delete('/banners/:id', (req, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM Banners WHERE id = ?`).run(id);
  res.json({deleted: true});
});

// --- Image Upload (Base64 safely stored in data/uploads) ---
adminRouter.post('/upload', (req, res) => {
  const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
  const match = dataUrl.match(/^data:(image\/(jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) {
    res.status(400).json({error: 'فرمت فایل باید تصویر JPEG، PNG یا WebP باشد.'});
    return;
  }

  const ext = match[2] === 'jpeg' || match[2] === 'jpg' ? 'jpg' : match[2];
  const buffer = Buffer.from(match[3], 'base64');
  if (buffer.length === 0 || buffer.length > 4 * 1024 * 1024) {
    res.status(400).json({error: 'حجم تصویر نباید بیشتر از ۴ مگابایت باشد.'});
    return;
  }

  const safeFilename = `img_${Date.now()}_${crypto.randomBytes(6).toString('hex')}.${ext}`;
  const targetPath = path.resolve(UPLOADS_DIR, safeFilename);
  if (!targetPath.startsWith(UPLOADS_DIR + path.sep)) {
    res.status(400).json({error: 'مسیر ذخیره فایل نامعتبر است.'});
    return;
  }

  fs.writeFileSync(targetPath, buffer);
  res.status(201).json({url: `/uploads/${safeFilename}`});
});
