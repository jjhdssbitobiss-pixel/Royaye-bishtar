import {Router} from 'express';
import {
  createToken,
  hashPassword,
  requireAuth,
  verifyPassword,
  type AuthenticatedRequest,
} from '../auth.ts';
import {db} from '../db.ts';

export const authRouter = Router();

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

authRouter.get('/admin-status', (_req, res) => {
  const envConfigured = Boolean(
    process.env.ADMIN_EMAIL?.trim() &&
      process.env.ADMIN_PASSWORD &&
      process.env.ADMIN_PASSWORD.length >= 6
  );
  const adminCount = (
    db
      .prepare(
        `SELECT COUNT(*) as c FROM Users u JOIN Roles r ON r.id = u.role_id WHERE r.name = 'admin'`
      )
      .get() as {c: number}
  ).c;

  res.json({
    needsAdminSetup: !envConfigured && adminCount === 0,
    envAdminConfigured: envConfigured,
  });
});

authRouter.post('/setup-admin', (req, res) => {
  const envConfigured = Boolean(
    process.env.ADMIN_EMAIL?.trim() &&
      process.env.ADMIN_PASSWORD &&
      process.env.ADMIN_PASSWORD.length >= 6
  );
  if (envConfigured) {
    res.status(403).json({
      error: 'حساب مدیر از طریق تنظیمات محیطی سرور پیکربندی شده است.',
    });
    return;
  }

  const fullName = typeof req.body?.full_name === 'string' ? req.body.full_name.trim() : '';
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (fullName.length < 2) {
    res.status(400).json({error: 'نام و نام خانوادگی مدیر باید حداقل ۲ کاراکتر باشد.'});
    return;
  }
  if (!isValidEmail(email)) {
    res.status(400).json({error: 'لطفاً یک ایمیل معتبر وارد کنید.'});
    return;
  }
  if (password.length < 6) {
    res.status(400).json({error: 'رمز عبور باید حداقل ۶ کاراکتر باشد.'});
    return;
  }

  const adminRole = db.prepare(`SELECT id, name, display_name FROM Roles WHERE name = 'admin'`).get() as {
    id: number;
    name: string;
    display_name: string;
  };

  try {
    const createAdminTx = db.transaction(() => {
      const existingAdmins = (
        db
          .prepare(`SELECT COUNT(*) as c FROM Users u JOIN Roles r ON r.id = u.role_id WHERE r.name = 'admin'`)
          .get() as {c: number}
      ).c;
      if (existingAdmins > 0) {
        throw new Error('ADMIN_ALREADY_EXISTS');
      }
      const existingEmail = db.prepare(`SELECT id FROM Users WHERE email = ?`).get(email);
      if (existingEmail) {
        throw new Error('EMAIL_EXISTS');
      }
      const passwordHash = hashPassword(password);
      const info = db
        .prepare(
          `INSERT INTO Users (role_id, full_name, email, phone, city, password_hash) VALUES (?, ?, ?, NULL, NULL, ?)`
        )
        .run(adminRole.id, fullName, email, passwordHash);
      return Number(info.lastInsertRowid);
    });

    const userId = createAdminTx();
    const token = createToken(userId, 'admin');
    res.status(201).json({
      token,
      user: {
        id: userId,
        full_name: fullName,
        email,
        phone: null,
        city: null,
        role_name: 'admin',
        role_display_name: adminRole.display_name,
      },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : '';
    if (msg === 'ADMIN_ALREADY_EXISTS') {
      res.status(409).json({error: 'حساب مدیر قبلاً ایجاد شده است.'});
      return;
    }
    if (msg === 'EMAIL_EXISTS') {
      res.status(409).json({error: 'این ایمیل قبلاً در سیستم ثبت شده است.'});
      return;
    }
    res.status(500).json({error: 'خطا در ایجاد حساب مدیر.'});
  }
});

authRouter.post('/register', (req, res) => {
  const fullName = typeof req.body?.full_name === 'string' ? req.body.full_name.trim() : '';
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : null;
  const city = typeof req.body?.city === 'string' ? req.body.city.trim() : null;
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (fullName.length < 2 || fullName.length > 80) {
    res.status(400).json({error: 'نام و نام خانوادگی باید بین ۲ تا ۸۰ کاراکتر باشد.'});
    return;
  }
  if (!isValidEmail(email)) {
    res.status(400).json({error: 'فرمت ایمیل واردشده معتبر نیست.'});
    return;
  }
  if (password.length < 6 || password.length > 100) {
    res.status(400).json({error: 'رمز عبور باید حداقل ۶ کاراکتر باشد.'});
    return;
  }

  const existing = db.prepare(`SELECT id FROM Users WHERE email = ?`).get(email);
  if (existing) {
    res.status(409).json({error: 'کاربری با این ایمیل قبلاً ثبت‌نام کرده است.'});
    return;
  }

  const customerRole = db
    .prepare(`SELECT id, name, display_name FROM Roles WHERE name = 'customer'`)
    .get() as {id: number; name: string; display_name: string};

  const passwordHash = hashPassword(password);
  const info = db
    .prepare(
      `INSERT INTO Users (role_id, full_name, email, phone, city, password_hash) VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(customerRole.id, fullName, email, phone || null, city || null, passwordHash);

  const userId = Number(info.lastInsertRowid);
  const token = createToken(userId, 'customer');

  res.status(201).json({
    token,
    user: {
      id: userId,
      full_name: fullName,
      email,
      phone: phone || null,
      city: city || null,
      role_name: 'customer',
      role_display_name: customerRole.display_name,
    },
  });
});

authRouter.post('/login', (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body?.password === 'string' ? req.body.password : '';

  if (!email || !password) {
    res.status(400).json({error: 'ایمیل و رمز عبور الزامی هستند.'});
    return;
  }

  const row = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.city, u.password_hash, u.is_blocked,
              r.name as role_name, r.display_name as role_display_name
       FROM Users u
       JOIN Roles r ON r.id = u.role_id
       WHERE u.email = ?`
    )
    .get(email) as
    | {
        id: number;
        full_name: string;
        email: string;
        phone: string | null;
        city: string | null;
        password_hash: string;
        is_blocked: number;
        role_name: string;
        role_display_name: string;
      }
    | undefined;

  if (!row || !verifyPassword(password, row.password_hash)) {
    res.status(401).json({error: 'ایمیل یا رمز عبور اشتباه است.'});
    return;
  }

  if (row.is_blocked) {
    res.status(403).json({error: 'حساب کاربری شما توسط مدیر فروشگاه مسدود شده است.'});
    return;
  }

  const token = createToken(row.id, row.role_name);
  res.json({
    token,
    user: {
      id: row.id,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      city: row.city,
      role_name: row.role_name,
      role_display_name: row.role_display_name,
    },
  });
});

authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({user: req.user});
});

authRouter.put('/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const fullName = typeof req.body?.full_name === 'string' ? req.body.full_name.trim() : '';
  const phone = typeof req.body?.phone === 'string' ? req.body.phone.trim() : null;
  const city = typeof req.body?.city === 'string' ? req.body.city.trim() : null;
  const currentPassword = typeof req.body?.current_password === 'string' ? req.body.current_password : '';
  const newPassword = typeof req.body?.new_password === 'string' ? req.body.new_password : '';

  if (fullName.length < 2 || fullName.length > 80) {
    res.status(400).json({error: 'نام و نام خانوادگی باید بین ۲ تا ۸۰ کاراکتر باشد.'});
    return;
  }

  if (newPassword) {
    if (newPassword.length < 6) {
      res.status(400).json({error: 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد.'});
      return;
    }
    const currentRow = db.prepare(`SELECT password_hash FROM Users WHERE id = ?`).get(userId) as {
      password_hash: string;
    };
    if (!currentPassword || !verifyPassword(currentPassword, currentRow.password_hash)) {
      res.status(400).json({error: 'رمز عبور فعلی صحیح نیست.'});
      return;
    }
    const newHash = hashPassword(newPassword);
    db.prepare(
      `UPDATE Users SET full_name = ?, phone = ?, city = ?, password_hash = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(fullName, phone || null, city || null, newHash, userId);
  } else {
    db.prepare(
      `UPDATE Users SET full_name = ?, phone = ?, city = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(fullName, phone || null, city || null, userId);
  }

  const updated = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.city,
              r.name as role_name, r.display_name as role_display_name
       FROM Users u JOIN Roles r ON r.id = u.role_id WHERE u.id = ?`
    )
    .get(userId);

  res.json({user: updated});
});
