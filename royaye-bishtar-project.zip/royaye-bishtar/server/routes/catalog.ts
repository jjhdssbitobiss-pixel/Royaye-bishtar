import {Router} from 'express';
import {optionalAuth, requireAuth, type AuthenticatedRequest} from '../auth.ts';
import {db} from '../db.ts';

export const catalogRouter = Router();

interface ProductListRow {
  id: number;
  category_id: number;
  brand_id: number | null;
  name: string;
  slug: string;
  sku: string | null;
  short_description: string | null;
  dimensions: string | null;
  material: string | null;
  features: string | null;
  price: number;
  stock_status: string;
  stock_quantity: number;
  is_active: number;
  is_featured: number;
  sort_order: number;
  view_count: number;
  created_at: string;
  category_name: string;
  category_slug: string;
  brand_name: string | null;
  primary_image: string | null;
  avg_rating: number;
  rating_count: number;
  review_count: number;
}

const PRODUCT_SELECT_SQL = `
  SELECT
    p.id, p.category_id, p.brand_id, p.name, p.slug, p.sku,
    p.short_description, p.dimensions, p.material, p.features,
    p.price, p.stock_status, p.stock_quantity, p.is_active, p.is_featured,
    p.sort_order, p.view_count, p.created_at,
    c.name AS category_name, c.slug AS category_slug,
    b.name AS brand_name,
    COALESCE(
      (SELECT image_url FROM ProductImages WHERE product_id = p.id AND is_primary = 1 ORDER BY sort_order ASC, id ASC LIMIT 1),
      (SELECT image_url FROM ProductImages WHERE product_id = p.id ORDER BY sort_order ASC, id ASC LIMIT 1)
    ) AS primary_image,
    COALESCE((SELECT ROUND(AVG(score), 2) FROM Ratings WHERE product_id = p.id), 0) AS avg_rating,
    (SELECT COUNT(*) FROM Ratings WHERE product_id = p.id) AS rating_count,
    (SELECT COUNT(*) FROM Reviews WHERE product_id = p.id AND status = 'approved') AS review_count
  FROM Products p
  JOIN Categories c ON c.id = p.category_id
  LEFT JOIN Brands b ON b.id = p.brand_id
`;

catalogRouter.get('/home', (_req, res) => {
  const banners = db
    .prepare(
      `SELECT id, title, subtitle, image_url, link_url, button_text, position, sort_order
       FROM Banners
       WHERE is_active = 1
       ORDER BY sort_order ASC, id ASC`
    )
    .all();

  const categories = db
    .prepare(
      `SELECT c.id, c.parent_id, c.name, c.slug, c.description, c.image_url, c.sort_order,
              (SELECT COUNT(*) FROM Products p WHERE p.is_active = 1 AND (p.category_id = c.id OR p.category_id IN (SELECT sub.id FROM Categories sub WHERE sub.parent_id = c.id))) AS product_count
       FROM Categories c
       WHERE c.is_active = 1
       ORDER BY c.sort_order ASC, c.id ASC`
    )
    .all();

  const brands = db.prepare(`SELECT id, name, slug, country, description FROM Brands ORDER BY name ASC`).all();

  const newest = db
    .prepare(`${PRODUCT_SELECT_SQL} WHERE p.is_active = 1 ORDER BY p.created_at DESC, p.id DESC LIMIT 6`)
    .all() as ProductListRow[];

  const featured = db
    .prepare(
      `${PRODUCT_SELECT_SQL} WHERE p.is_active = 1 AND p.is_featured = 1 ORDER BY p.sort_order ASC, p.id DESC LIMIT 6`
    )
    .all() as ProductListRow[];

  const mostViewed = db
    .prepare(`${PRODUCT_SELECT_SQL} WHERE p.is_active = 1 ORDER BY p.view_count DESC, p.id DESC LIMIT 6`)
    .all() as ProductListRow[];

  const highestRated = db
    .prepare(
      `${PRODUCT_SELECT_SQL} WHERE p.is_active = 1 ORDER BY avg_rating DESC, rating_count DESC, p.view_count DESC LIMIT 6`
    )
    .all() as ProductListRow[];

  res.json({
    banners,
    categories,
    brands,
    newest,
    featured,
    mostViewed,
    highestRated,
  });
});

catalogRouter.get('/categories', (_req, res) => {
  const categories = db
    .prepare(
      `SELECT c.id, c.parent_id, c.name, c.slug, c.description, c.image_url, c.sort_order, c.is_active,
              p.name AS parent_name,
              (SELECT COUNT(*) FROM Products pr WHERE pr.is_active = 1 AND (pr.category_id = c.id OR pr.category_id IN (SELECT sub.id FROM Categories sub WHERE sub.parent_id = c.id))) AS product_count
       FROM Categories c
       LEFT JOIN Categories p ON p.id = c.parent_id
       WHERE c.is_active = 1
       ORDER BY COALESCE(c.parent_id, c.id), c.parent_id IS NOT NULL, c.sort_order ASC, c.id ASC`
    )
    .all();
  res.json({categories});
});

catalogRouter.get('/brands', (_req, res) => {
  const brands = db.prepare(`SELECT id, name, slug, country, description FROM Brands ORDER BY name ASC`).all();
  res.json({brands});
});

catalogRouter.get('/products', (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const categoryId = req.query.categoryId ? Number(req.query.categoryId) : null;
  const categorySlug = typeof req.query.category === 'string' ? req.query.category.trim() : '';
  const brandId = req.query.brandId ? Number(req.query.brandId) : null;
  const minPrice = req.query.minPrice ? Number(req.query.minPrice) : null;
  const maxPrice = req.query.maxPrice ? Number(req.query.maxPrice) : null;
  const stockStatus = typeof req.query.stockStatus === 'string' ? req.query.stockStatus.trim() : '';
  const feature = typeof req.query.feature === 'string' ? req.query.feature.trim() : '';
  const featuredOnly = req.query.featured === '1' || req.query.featured === 'true';
  const sort = typeof req.query.sort === 'string' ? req.query.sort : 'order';

  const whereClauses: string[] = ['p.is_active = 1'];
  const params: (string | number)[] = [];

  if (q) {
    whereClauses.push(
      `(p.name LIKE ? OR p.short_description LIKE ? OR p.description LIKE ? OR p.material LIKE ? OR p.features LIKE ? OR b.name LIKE ?)`
    );
    const pattern = `%${q}%`;
    params.push(pattern, pattern, pattern, pattern, pattern, pattern);
  }

  let resolvedCategoryId = categoryId && !Number.isNaN(categoryId) ? categoryId : null;
  if (!resolvedCategoryId && categorySlug) {
    const catRow = db.prepare(`SELECT id FROM Categories WHERE slug = ?`).get(categorySlug) as
      | {id: number}
      | undefined;
    if (catRow) resolvedCategoryId = catRow.id;
  }

  if (resolvedCategoryId) {
    whereClauses.push(
      `(p.category_id = ? OR p.category_id IN (SELECT id FROM Categories WHERE parent_id = ?))`
    );
    params.push(resolvedCategoryId, resolvedCategoryId);
  }

  if (brandId && !Number.isNaN(brandId)) {
    whereClauses.push(`p.brand_id = ?`);
    params.push(brandId);
  }

  if (minPrice !== null && !Number.isNaN(minPrice)) {
    whereClauses.push(`p.price >= ?`);
    params.push(minPrice);
  }

  if (maxPrice !== null && !Number.isNaN(maxPrice)) {
    whereClauses.push(`p.price <= ?`);
    params.push(maxPrice);
  }

  if (stockStatus && ['in_stock', 'low_stock', 'out_of_stock'].includes(stockStatus)) {
    whereClauses.push(`p.stock_status = ?`);
    params.push(stockStatus);
  }

  if (feature) {
    whereClauses.push(`(p.features LIKE ? OR p.material LIKE ? OR p.dimensions LIKE ?)`);
    const fp = `%${feature}%`;
    params.push(fp, fp, fp);
  }

  if (featuredOnly) {
    whereClauses.push(`p.is_featured = 1`);
  }

  let orderBy = `p.sort_order ASC, p.id DESC`;
  switch (sort) {
    case 'newest':
      orderBy = `p.created_at DESC, p.id DESC`;
      break;
    case 'popular':
      orderBy = `p.view_count DESC, p.id DESC`;
      break;
    case 'rating':
      orderBy = `avg_rating DESC, rating_count DESC, p.id DESC`;
      break;
    case 'price_asc':
      orderBy = `p.price ASC, p.id DESC`;
      break;
    case 'price_desc':
      orderBy = `p.price DESC, p.id DESC`;
      break;
    default:
      orderBy = `p.sort_order ASC, p.id DESC`;
  }

  const sql = `${PRODUCT_SELECT_SQL} WHERE ${whereClauses.join(' AND ')} ORDER BY ${orderBy}`;
  const products = db.prepare(sql).all(...params);
  res.json({products});
});

catalogRouter.get('/products/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
  const idParam = req.params.id;
  const numericId = Number(idParam);
  const trackView = req.query.track === '1';
  const reviewSort = req.query.reviewSort === 'helpful' ? 'helpful' : 'newest';

  const productRow = db
    .prepare(
      `SELECT p.*,
              c.name AS category_name, c.slug AS category_slug, c.parent_id AS category_parent_id,
              pc.name AS parent_category_name,
              b.name AS brand_name, b.country AS brand_country, b.description AS brand_description
       FROM Products p
       JOIN Categories c ON c.id = p.category_id
       LEFT JOIN Categories pc ON pc.id = c.parent_id
       LEFT JOIN Brands b ON b.id = p.brand_id
       WHERE ${Number.isInteger(numericId) && numericId > 0 ? 'p.id = ?' : 'p.slug = ?'}`
    )
    .get(Number.isInteger(numericId) && numericId > 0 ? numericId : idParam) as
    | (Record<string, unknown> & {id: number; is_active: number; category_id: number})
    | undefined;

  if (!productRow || (!productRow.is_active && req.user?.role_name !== 'admin')) {
    res.status(404).json({error: 'محصول مورد نظر یافت نشد.'});
    return;
  }

  if (trackView) {
    db.prepare(`UPDATE Products SET view_count = view_count + 1 WHERE id = ?`).run(productRow.id);
    productRow.view_count = Number(productRow.view_count || 0) + 1;
  }

  const images = db
    .prepare(
      `SELECT id, image_url, alt_text, is_primary, sort_order
       FROM ProductImages
       WHERE product_id = ?
       ORDER BY is_primary DESC, sort_order ASC, id ASC`
    )
    .all(productRow.id);

  const specifications = db
    .prepare(
      `SELECT id, spec_key, spec_value, sort_order
       FROM ProductSpecifications
       WHERE product_id = ?
       ORDER BY sort_order ASC, id ASC`
    )
    .all(productRow.id);

  const ratingSummary = db
    .prepare(
      `SELECT
        COALESCE(ROUND(AVG(score), 2), 0) AS avg_rating,
        COUNT(*) AS total_ratings,
        SUM(CASE WHEN score = 5 THEN 1 ELSE 0 END) AS star_5,
        SUM(CASE WHEN score = 4 THEN 1 ELSE 0 END) AS star_4,
        SUM(CASE WHEN score = 3 THEN 1 ELSE 0 END) AS star_3,
        SUM(CASE WHEN score = 2 THEN 1 ELSE 0 END) AS star_2,
        SUM(CASE WHEN score = 1 THEN 1 ELSE 0 END) AS star_1
       FROM Ratings
       WHERE product_id = ?`
    )
    .get(productRow.id);

  const reviewOrderSql =
    reviewSort === 'helpful'
      ? `rv.helpful_count DESC, rv.created_at DESC`
      : `rv.created_at DESC, rv.id DESC`;

  const currentUserId = req.user?.id ?? -1;

  const reviews = db
    .prepare(
      `SELECT
        rv.id, rv.product_id, rv.user_id, rv.title, rv.comment, rv.status,
        rv.helpful_count, rv.created_at, rv.updated_at,
        u.full_name AS user_name,
        rt.score AS user_rating,
        EXISTS(SELECT 1 FROM ReviewHelpfulVotes v WHERE v.review_id = rv.id AND v.user_id = ?) AS user_voted_helpful
       FROM Reviews rv
       JOIN Users u ON u.id = rv.user_id
       LEFT JOIN Ratings rt ON rt.product_id = rv.product_id AND rt.user_id = rv.user_id
       WHERE rv.product_id = ? AND rv.status = 'approved'
       ORDER BY ${reviewOrderSql}`
    )
    .all(currentUserId, productRow.id);

  let myRating: number | null = null;
  let myReviews: unknown[] = [];
  if (req.user) {
    const rt = db
      .prepare(`SELECT score FROM Ratings WHERE product_id = ? AND user_id = ?`)
      .get(productRow.id, req.user.id) as {score: number} | undefined;
    myRating = rt ? rt.score : null;

    myReviews = db
      .prepare(
        `SELECT id, title, comment, status, admin_note, helpful_count, created_at, updated_at
         FROM Reviews
         WHERE product_id = ? AND user_id = ?
         ORDER BY created_at DESC`
      )
      .all(productRow.id, req.user.id);
  }

  const related = db
    .prepare(
      `${PRODUCT_SELECT_SQL}
       WHERE p.is_active = 1 AND p.id != ? AND p.category_id = ?
       ORDER BY p.is_featured DESC, p.view_count DESC
       LIMIT 3`
    )
    .all(productRow.id, productRow.category_id);

  res.json({
    product: productRow,
    images,
    specifications,
    ratingSummary,
    reviews,
    myRating,
    myReviews,
    related,
  });
});

catalogRouter.post('/products/:id/rate', requireAuth, (req: AuthenticatedRequest, res) => {
  const productId = Number(req.params.id);
  const score = Number(req.body?.score);

  if (!Number.isInteger(productId) || productId <= 0) {
    res.status(400).json({error: 'شناسه محصول نامعتبر است.'});
    return;
  }
  if (!Number.isInteger(score) || score < 1 || score > 5) {
    res.status(400).json({error: 'امتیاز باید عددی صحیح بین ۱ تا ۵ باشد.'});
    return;
  }

  const product = db.prepare(`SELECT id FROM Products WHERE id = ? AND is_active = 1`).get(productId);
  if (!product) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }

  db.prepare(
    `INSERT INTO Ratings (product_id, user_id, score)
     VALUES (?, ?, ?)
     ON CONFLICT(product_id, user_id) DO UPDATE SET
       score = excluded.score,
       updated_at = datetime('now')`
  ).run(productId, req.user!.id, score);

  const ratingSummary = db
    .prepare(
      `SELECT
        COALESCE(ROUND(AVG(score), 2), 0) AS avg_rating,
        COUNT(*) AS total_ratings,
        SUM(CASE WHEN score = 5 THEN 1 ELSE 0 END) AS star_5,
        SUM(CASE WHEN score = 4 THEN 1 ELSE 0 END) AS star_4,
        SUM(CASE WHEN score = 3 THEN 1 ELSE 0 END) AS star_3,
        SUM(CASE WHEN score = 2 THEN 1 ELSE 0 END) AS star_2,
        SUM(CASE WHEN score = 1 THEN 1 ELSE 0 END) AS star_1
       FROM Ratings
       WHERE product_id = ?`
    )
    .get(productId);

  res.json({myRating: score, ratingSummary});
});

catalogRouter.post('/products/:id/reviews', requireAuth, (req: AuthenticatedRequest, res) => {
  const productId = Number(req.params.id);
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const comment = typeof req.body?.comment === 'string' ? req.body.comment.trim() : '';
  const score = req.body?.score !== undefined && req.body?.score !== null ? Number(req.body.score) : null;

  if (!Number.isInteger(productId) || productId <= 0) {
    res.status(400).json({error: 'شناسه محصول نامعتبر است.'});
    return;
  }
  if (comment.length < 8 || comment.length > 1500) {
    res.status(400).json({error: 'متن نظر باید بین ۸ تا ۱۵۰۰ کاراکتر باشد.'});
    return;
  }
  if (title.length > 120) {
    res.status(400).json({error: 'عنوان نظر نمی‌تواند بیشتر از ۱۲۰ کاراکتر باشد.'});
    return;
  }
  if (score !== null && (!Number.isInteger(score) || score < 1 || score > 5)) {
    res.status(400).json({error: 'امتیاز باید بین ۱ تا ۵ ستاره باشد.'});
    return;
  }

  const product = db.prepare(`SELECT id FROM Products WHERE id = ? AND is_active = 1`).get(productId);
  if (!product) {
    res.status(404).json({error: 'محصول یافت نشد.'});
    return;
  }

  // Anti-duplicate and anti-spam checks
  const duplicate = db
    .prepare(`SELECT id FROM Reviews WHERE product_id = ? AND user_id = ? AND comment = ?`)
    .get(productId, req.user!.id, comment);
  if (duplicate) {
    res.status(409).json({error: 'این نظر قبلاً توسط شما برای این محصول ثبت شده است.'});
    return;
  }

  const pendingForProduct = db
    .prepare(`SELECT id FROM Reviews WHERE product_id = ? AND user_id = ? AND status = 'pending'`)
    .get(productId, req.user!.id);
  if (pendingForProduct) {
    res.status(409).json({
      error: 'شما یک نظر در انتظار تایید برای این محصول دارید. می‌توانید همان نظر را ویرایش کنید.',
    });
    return;
  }

  const recentSpam = db
    .prepare(
      `SELECT id FROM Reviews WHERE user_id = ? AND created_at > datetime('now', '-30 seconds')`
    )
    .get(req.user!.id);
  if (recentSpam) {
    res.status(429).json({error: 'لطفاً ۳۰ ثانیه پس از ثبت نظر قبلی مجدداً تلاش کنید.'});
    return;
  }

  const insertTx = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO Reviews (product_id, user_id, title, comment, status) VALUES (?, ?, ?, ?, 'pending')`
      )
      .run(productId, req.user!.id, title || null, comment);

    if (score !== null) {
      db.prepare(
        `INSERT INTO Ratings (product_id, user_id, score)
         VALUES (?, ?, ?)
         ON CONFLICT(product_id, user_id) DO UPDATE SET
           score = excluded.score,
           updated_at = datetime('now')`
      ).run(productId, req.user!.id, score);
    }

    return Number(info.lastInsertRowid);
  });

  const reviewId = insertTx();
  const createdReview = db
    .prepare(`SELECT id, title, comment, status, helpful_count, created_at, updated_at FROM Reviews WHERE id = ?`)
    .get(reviewId);

  res.status(201).json({
    review: createdReview,
    message: 'نظر شما ثبت شد و پس از بررسی و تایید مدیر به صورت عمومی نمایش داده خواهد شد.',
  });
});

catalogRouter.get('/my-reviews', requireAuth, (req: AuthenticatedRequest, res) => {
  const reviews = db
    .prepare(
      `SELECT rv.id, rv.product_id, rv.title, rv.comment, rv.status, rv.admin_note,
              rv.helpful_count, rv.created_at, rv.updated_at,
              p.name AS product_name, p.slug AS product_slug,
              (SELECT image_url FROM ProductImages WHERE product_id = p.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) AS product_image,
              rt.score AS my_rating
       FROM Reviews rv
       JOIN Products p ON p.id = rv.product_id
       LEFT JOIN Ratings rt ON rt.product_id = rv.product_id AND rt.user_id = rv.user_id
       WHERE rv.user_id = ?
       ORDER BY rv.created_at DESC`
    )
    .all(req.user!.id);

  res.json({reviews});
});

catalogRouter.put('/reviews/:reviewId', requireAuth, (req: AuthenticatedRequest, res) => {
  const reviewId = Number(req.params.reviewId);
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const comment = typeof req.body?.comment === 'string' ? req.body.comment.trim() : '';

  if (!Number.isInteger(reviewId) || reviewId <= 0) {
    res.status(400).json({error: 'شناسه نظر نامعتبر است.'});
    return;
  }
  if (comment.length < 8 || comment.length > 1500) {
    res.status(400).json({error: 'متن نظر باید بین ۸ تا ۱۵۰۰ کاراکتر باشد.'});
    return;
  }
  if (title.length > 120) {
    res.status(400).json({error: 'عنوان نظر نمی‌تواند بیشتر از ۱۲۰ کاراکتر باشد.'});
    return;
  }

  const existing = db.prepare(`SELECT id, user_id, product_id FROM Reviews WHERE id = ?`).get(reviewId) as
    | {id: number; user_id: number; product_id: number}
    | undefined;
  if (!existing) {
    res.status(404).json({error: 'نظر یافت نشد.'});
    return;
  }
  if (existing.user_id !== req.user!.id) {
    res.status(403).json({error: 'شما مجاز به ویرایش نظر دیگران نیستید.'});
    return;
  }

  db.prepare(
    `UPDATE Reviews
     SET title = ?, comment = ?, status = 'pending', admin_note = NULL, updated_at = datetime('now')
     WHERE id = ?`
  ).run(title || null, comment, reviewId);

  const updated = db.prepare(`SELECT * FROM Reviews WHERE id = ?`).get(reviewId);
  res.json({
    review: updated,
    message: 'نظر شما ویرایش شد و مجدداً در صف تایید مدیر قرار گرفت.',
  });
});

catalogRouter.delete('/reviews/:reviewId', requireAuth, (req: AuthenticatedRequest, res) => {
  const reviewId = Number(req.params.reviewId);
  if (!Number.isInteger(reviewId) || reviewId <= 0) {
    res.status(400).json({error: 'شناسه نظر نامعتبر است.'});
    return;
  }

  const existing = db.prepare(`SELECT id, user_id FROM Reviews WHERE id = ?`).get(reviewId) as
    | {id: number; user_id: number}
    | undefined;
  if (!existing) {
    res.status(404).json({error: 'نظر یافت نشد.'});
    return;
  }
  if (existing.user_id !== req.user!.id && req.user!.role_name !== 'admin') {
    res.status(403).json({error: 'شما مجاز به حذف این نظر نیستید.'});
    return;
  }

  db.prepare(`DELETE FROM Reviews WHERE id = ?`).run(reviewId);
  res.json({deleted: true});
});

catalogRouter.post('/reviews/:reviewId/helpful', requireAuth, (req: AuthenticatedRequest, res) => {
  const reviewId = Number(req.params.reviewId);
  if (!Number.isInteger(reviewId) || reviewId <= 0) {
    res.status(400).json({error: 'شناسه نظر نامعتبر است.'});
    return;
  }

  const review = db
    .prepare(`SELECT id, status FROM Reviews WHERE id = ?`)
    .get(reviewId) as {id: number; status: string} | undefined;
  if (!review || review.status !== 'approved') {
    res.status(404).json({error: 'نظر تاییدشده یافت نشد.'});
    return;
  }

  const toggleTx = db.transaction(() => {
    const existingVote = db
      .prepare(`SELECT id FROM ReviewHelpfulVotes WHERE review_id = ? AND user_id = ?`)
      .get(reviewId, req.user!.id) as {id: number} | undefined;

    let voted = false;
    if (existingVote) {
      db.prepare(`DELETE FROM ReviewHelpfulVotes WHERE id = ?`).run(existingVote.id);
      voted = false;
    } else {
      db.prepare(`INSERT INTO ReviewHelpfulVotes (review_id, user_id) VALUES (?, ?)`).run(
        reviewId,
        req.user!.id
      );
      voted = true;
    }

    const countRow = db
      .prepare(`SELECT COUNT(*) as c FROM ReviewHelpfulVotes WHERE review_id = ?`)
      .get(reviewId) as {c: number};

    db.prepare(`UPDATE Reviews SET helpful_count = ? WHERE id = ?`).run(countRow.c, reviewId);
    return {helpful_count: countRow.c, user_voted_helpful: voted ? 1 : 0};
  });

  const result = toggleTx();
  res.json(result);
});
