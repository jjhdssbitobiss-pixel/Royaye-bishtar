import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import {hashPassword} from './auth.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
export const UPLOADS_DIR = path.resolve(DATA_DIR, 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, {recursive: true});
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, {recursive: true});
}

const DB_PATH = path.resolve(DATA_DIR, 'store.db');
export const db = new Database(DB_PATH);

db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS Roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS Users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      role_id INTEGER NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT,
      city TEXT,
      password_hash TEXT NOT NULL,
      is_blocked INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (role_id) REFERENCES Roles(id)
    );

    CREATE TABLE IF NOT EXISTS Categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      image_url TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (parent_id) REFERENCES Categories(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS Brands (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      slug TEXT NOT NULL UNIQUE,
      country TEXT,
      description TEXT,
      logo_url TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS Products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category_id INTEGER NOT NULL,
      brand_id INTEGER,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      sku TEXT,
      short_description TEXT,
      description TEXT NOT NULL,
      dimensions TEXT,
      material TEXT,
      features TEXT,
      price INTEGER NOT NULL DEFAULT 0,
      stock_status TEXT NOT NULL DEFAULT 'in_stock' CHECK (stock_status IN ('in_stock', 'low_stock', 'out_of_stock')),
      stock_quantity INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      is_featured INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      view_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (category_id) REFERENCES Categories(id) ON DELETE RESTRICT,
      FOREIGN KEY (brand_id) REFERENCES Brands(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS ProductImages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      image_url TEXT NOT NULL,
      alt_text TEXT,
      is_primary INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (product_id) REFERENCES Products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ProductSpecifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      spec_key TEXT NOT NULL,
      spec_value TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (product_id) REFERENCES Products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      title TEXT,
      comment TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
      admin_note TEXT,
      helpful_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (product_id) REFERENCES Products(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ReviewHelpfulVotes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      review_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (review_id, user_id),
      FOREIGN KEY (review_id) REFERENCES Reviews(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Ratings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      score INTEGER NOT NULL CHECK (score BETWEEN 1 AND 5),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (product_id, user_id),
      FOREIGN KEY (product_id) REFERENCES Products(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Banners (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      subtitle TEXT,
      image_url TEXT NOT NULL,
      link_url TEXT,
      button_text TEXT,
      position TEXT NOT NULL DEFAULT 'hero' CHECK (position IN ('hero', 'promo')),
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_products_category ON Products(category_id);
    CREATE INDEX IF NOT EXISTS idx_products_brand ON Products(brand_id);
    CREATE INDEX IF NOT EXISTS idx_products_active ON Products(is_active, is_featured, sort_order);
    CREATE INDEX IF NOT EXISTS idx_reviews_product_status ON Reviews(product_id, status);
    CREATE INDEX IF NOT EXISTS idx_ratings_product ON Ratings(product_id);
  `);

  seedInitialData();
}

function seedInitialData(): void {
  const insertRole = db.prepare(
    `INSERT OR IGNORE INTO Roles (name, display_name, description) VALUES (?, ?, ?)`
  );
  insertRole.run('admin', 'مدیر فروشگاه', 'دسترسی کامل به مدیریت محصولات، دسته‌بندی‌ها، نظرات، کاربران و بنرها');
  insertRole.run('customer', 'مشتری', 'مشاهده کاتالوگ، ثبت نظر و امتیازدهی به محصولات');

  // If ADMIN_EMAIL and ADMIN_PASSWORD are configured via environment variables, ensure admin account exists
  const envAdminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const envAdminPassword = process.env.ADMIN_PASSWORD;
  if (envAdminEmail && envAdminPassword && envAdminPassword.length >= 6) {
    const adminRole = db.prepare(`SELECT id FROM Roles WHERE name = 'admin'`).get() as {id: number};
    const existing = db.prepare(`SELECT id FROM Users WHERE email = ?`).get(envAdminEmail) as
      | {id: number}
      | undefined;
    const passwordHash = hashPassword(envAdminPassword);
    if (existing) {
      db.prepare(`UPDATE Users SET role_id = ?, password_hash = ?, is_blocked = 0, updated_at = datetime('now') WHERE id = ?`).run(
        adminRole.id,
        passwordHash,
        existing.id
      );
    } else {
      db.prepare(
        `INSERT INTO Users (role_id, full_name, email, phone, city, password_hash) VALUES (?, ?, ?, ?, ?, ?)`
      ).run(adminRole.id, 'مدیر سیستم', envAdminEmail, null, 'تهران', passwordHash);
    }
  }

  const categoryCount = (db.prepare(`SELECT COUNT(*) as c FROM Categories`).get() as {c: number}).c;
  if (categoryCount === 0) {
    const insertCat = db.prepare(
      `INSERT INTO Categories (parent_id, name, slug, description, image_url, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)`
    );

    const mattressCat = insertCat.run(
      null,
      'تشک',
      'mattress',
      'انواع تشک‌های طبی، ارتوپدیک، فنر منفصل و مموری فوم برای خوابی سالم و بدون درد کمر',
      '/src/assets/images/product_mattress_royal_1795699970591.jpg',
      1
    );
    const pillowCat = insertCat.run(
      null,
      'بالش',
      'pillow',
      'بالش‌های طبی مموری فوم، میکروفایبر و ضد حساسیت متناسب با حالت خواب شما',
      '/src/assets/images/product_pillow_memory_1795699970843.jpg',
      2
    );
    const duvetCat = insertCat.run(
      null,
      'روتختی',
      'duvet-set',
      'سرویس‌های روتختی کتان ساتین، نخ پنبه و تنسل با دوخت دقیق و رنگ‌های آرامش‌بخش',
      '/src/assets/images/product_duvet_sky_1795699971673.jpg',
      3
    );
    const sheetCat = insertCat.run(
      null,
      'ملحفه',
      'bed-sheet',
      'ملحفه‌های کش‌دوز و تخت‌خواب با الیاف طبیعی خنک و تنفس‌پذیر',
      '/src/assets/images/product_duvet_sky_1795699971673.jpg',
      4
    );
    const blanketCat = insertCat.run(
      null,
      'پتو',
      'blanket',
      'پتوهای بافت پنبه‌ای، چهارفصل و مسافرتی سبک با لطافت ماندگار',
      '/src/assets/images/product_blanket_knit_1795699969636.jpg',
      5
    );
    const protectorCat = insertCat.run(
      null,
      'محافظ تشک',
      'mattress-protector',
      'محافظ‌های ضدآب و تنفس‌پذیر کتان برای افزایش طول عمر و بهداشت تشک',
      '/src/assets/images/product_protector_cotton_1795699972542.jpg',
      6
    );
    const kidsCat = insertCat.run(
      null,
      'کالای خواب کودک',
      'kids-bedding',
      'سرویس خواب و تشک استاندارد کودک و نوزاد با الیاف ارگانیک ضد آلرژی',
      '/src/assets/images/product_kids_bedding_1795699973341.jpg',
      7
    );
    insertCat.run(
      null,
      'سایر محصولات',
      'other-products',
      'تاپر تشک، روبالشی، کوسن و اکسسوری‌های تکمیلی اتاق خواب',
      '/src/assets/images/hero_luxury_bedroom_1795699969658.jpg',
      8
    );

    // Subcategories
    insertCat.run(
      mattressCat.lastInsertRowid,
      'تشک طبی و ارتوپدیک',
      'orthopedic-mattress',
      'طراحی‌شده برای حمایت استاندارد از ستون فقرات و کاهش فشار عضلانی',
      '/src/assets/images/banner_orthopedic_sleep_1795699970249.jpg',
      1
    );
    insertCat.run(
      mattressCat.lastInsertRowid,
      'تشک فنر منفصل (پاکت اسپرینگ)',
      'pocket-spring-mattress',
      'فنرهای مستقل بدون انتقال لرزش و صدا برای خواب دونفره آرام',
      '/src/assets/images/product_mattress_royal_1795699970591.jpg',
      2
    );
    insertCat.run(
      pillowCat.lastInsertRowid,
      'بالش مموری فوم',
      'memory-foam-pillow',
      'فرم‌پذیر هوشمند با قوس گردنی استاندارد',
      '/src/assets/images/product_pillow_memory_1795699970843.jpg',
      1
    );
    insertCat.run(
      duvetCat.lastInsertRowid,
      'روتختی کتان ساتین',
      'sateen-duvet',
      'بافت متراکم ۴۰۰ شانه با لطافت ابریشمی',
      '/src/assets/images/product_duvet_sky_1795699971673.jpg',
      1
    );

    // Seed Brands
    const insertBrand = db.prepare(
      `INSERT INTO Brands (name, slug, country, description) VALUES (?, ?, ?, ?)`
    );
    const b1 = insertBrand.run('نیلگون سافت', 'nilgoon-soft', 'ایران', 'تولیدکننده تخصصی تشک‌های ارتوپدیک و منسوجات لوکس اتاق خواب');
    const b2 = insertBrand.run('رویا آسایش', 'roya-asayesh', 'ایران', 'پیشگام در تولید تشک‌های فنر منفصل و بالش‌های طبی هوشمند');
    const b3 = insertBrand.run('ابریشم پامچال', 'pamchal-textile', 'ایران', 'بافندگی کتان ارگانیک، روتختی ساتین و ملحفه هتلی');
    const b4 = insertBrand.run('آسمان کودک', 'aseman-kids', 'ایران', 'تخصصی‌ترین برند کالای خواب ضد حساسیت نوزاد و کودک');

    // Seed Banners
    const insertBanner = db.prepare(
      `INSERT INTO Banners (title, subtitle, image_url, link_url, button_text, position, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
    );
    insertBanner.run(
      'خوابی عمیق در آغوش آرامش با رویای بیشتر',
      'مجموعه منتخب تشک‌های ارتوپدیک، بالش‌های طبی و منسوجات کتان ۱۰۰٪ طبیعی با استاندارد ارگونومیک',
      '/src/assets/images/hero_luxury_bedroom_1795699969658.jpg',
      '/catalog',
      'مشاهده کاتالوگ محصولات',
      'hero',
      1
    );
    insertBanner.run(
      'فناوری تهویه سه‌بعدی در تشک‌های طبی ارتوپدیک',
      'طراحی چندلایه با مموری فوم خنک‌کننده و پارچه گردبافت ضد تعریق برای حمایت کامل از ستون فقرات',
      '/src/assets/images/banner_orthopedic_sleep_1795699970249.jpg',
      '/catalog?category=mattress',
      'بررسی تشک‌های طبی',
      'promo',
      1
    );

    // Seed 8 Rich Sample Products
    const insertProduct = db.prepare(`
      INSERT INTO Products (
        category_id, brand_id, name, slug, sku, short_description, description,
        dimensions, material, features, price, stock_status, stock_quantity,
        is_active, is_featured, sort_order, view_count
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
    `);
    const insertImage = db.prepare(
      `INSERT INTO ProductImages (product_id, image_url, alt_text, is_primary, sort_order) VALUES (?, ?, ?, ?, ?)`
    );
    const insertSpec = db.prepare(
      `INSERT INTO ProductSpecifications (product_id, spec_key, spec_value, sort_order) VALUES (?, ?, ?, ?)`
    );

    const sampleProducts = [
      {
        categoryId: Number(mattressCat.lastInsertRowid),
        brandId: Number(b1.lastInsertRowid),
        name: 'تشک طبی فنر منفصل مدل رویال اسکای',
        slug: 'royal-sky-pocket-mattress',
        sku: 'MAT-RS-200',
        shortDescription: 'تشک ۳۰ سانتی‌متری با فنرهای پاکتی ۵ ناحیه‌ای و لایه مموری فوم ژل‌دار',
        description:
          'تشک رویال اسکای ترکیبی مهندسی‌شده از فنرهای منفصل پاکت اسپرینگ و فوم حافظه‌دار خنک‌کننده است. این ساختار باعث می‌شود هر نقطه از بدن به صورت مستقل پشتیبانی شود و حرکت طرف مقابل در خواب دونفره به هیچ عنوان منتقل نگردد. پارچه رویه از کتان ارگانیک گردبافت با قابلیت تنفس بالا و خاصیت ضد حساسیت تهیه شده است.',
        dimensions: '۱۶۰×۲۰۰ سانتی‌متر (دونفره استاندارد) · قابل سفارش در ۱۸۰×۲۰۰ و ۹۰×۲۰۰',
        material: 'پارچه گردبافت کتان ارگانیک، مموری فوم ژل‌دار، فنر منفصل فولادی کربن‌دار',
        features: 'بدون انتقال لرزش، حمایت ۵ ناحیه‌ای ستون فقرات، تهویه جانبی ۳۶۰ درجه، ۱۰ سال ضمانت ساختار',
        price: 24800000,
        stockStatus: 'in_stock',
        stockQuantity: 14,
        isFeatured: 1,
        sortOrder: 1,
        viewCount: 142,
        images: [
          '/src/assets/images/product_mattress_royal_1795699970591.jpg',
          '/src/assets/images/banner_orthopedic_sleep_1795699970249.jpg',
        ],
        specs: [
          ['ارتفاع تشک', '۳۰ سانتی‌متر'],
          ['درجه سفتی', 'متوسط رو به سفت (۶.۵ از ۱۰)'],
          ['تعداد فنر', '۸۵۰ فنر منفصل در سایز دونفره'],
          ['تحمل وزن', 'تا ۱۳۵ کیلوگرم برای هر نفر'],
          ['نوع رویه', 'کتان ارگانیک ضد تعریق و آنتی‌باکتریال'],
          ['مدت ضمانت', '۱۰ سال گارانتی تعویض ساختار'],
        ],
      },
      {
        categoryId: Number(mattressCat.lastInsertRowid),
        brandId: Number(b2.lastInsertRowid),
        name: 'تشک تمام طبی ارتوپدیک مدل ارگونومیک پلاس',
        slug: 'ergonomic-plus-orthopedic-mattress',
        sku: 'MAT-EP-180',
        shortDescription: 'تشک تمام فوم بدون فنر مناسب افراد دارای دیسک کمر و حساسیت ستون فقرات',
        description:
          'تشک ارگونومیک پلاس بدون استفاده از فنر و با ترکیب سه لایه فوم با چگالی‌های متفاوت طراحی شده است. هسته مرکزی از ریباند فشرده و لایه فوقانی از مموری فوم ویسکوالاستیک هوشمند تشکیل شده تا قوس طبیعی کمر در تمام طول شب حفظ شود.',
        dimensions: '۹۰×۲۰۰ سانتی‌متر (تک‌نفره) · ۱۲۰×۲۰۰ · ۱۶۰×۲۰۰',
        material: 'اسفنج ریباند با دانسیته بالا، مموری فوم طبی ۵ سانتی‌متری، روکش ژاکارد تنفس‌پذیر',
        features: 'مناسب کمردرد و دیسک کمر، دو رویه تابستانه و زمستانه، دستگیره‌های تقویت‌شده حمل',
        price: 18500000,
        stockStatus: 'in_stock',
        stockQuantity: 9,
        isFeatured: 1,
        sortOrder: 2,
        viewCount: 118,
        images: [
          '/src/assets/images/banner_orthopedic_sleep_1795699970249.jpg',
          '/src/assets/images/product_mattress_royal_1795699970591.jpg',
        ],
        specs: [
          ['ارتفاع تشک', '۲۶ سانتی‌متر'],
          ['درجه سفتی', 'طبی سفت (۸ از ۱۰)'],
          ['ساختار داخلی', 'تمام فوم سه‌لایه بدون فنر'],
          ['قابلیت استفاده', 'دو رویه (فصل گرم و سرد)'],
          ['مدت ضمانت', '۸ سال گارانتی'],
        ],
      },
      {
        categoryId: Number(pillowCat.lastInsertRowid),
        brandId: Number(b2.lastInsertRowid),
        name: 'جفت بالش طبی میکروفایبر و الیاف هوشمند مدل ابر سفید',
        slug: 'white-cloud-microfiber-pillow-pair',
        sku: 'PIL-WC-02',
        shortDescription: 'نرم، پف‌دار و قابل شستشو با حاشیه نوار آبی آسمانی و رویه کتان ۱۰۰٪',
        description:
          'بالش ابر سفید با الیاف میکروژل کره‌ای و روکش کتان خالص دوخته‌شده است تا حس بالش‌های هتلی پنج‌ستاره را به خانه شما بیاورد. به سرعت به فرم اولیه بازمی‌گردد و برای افرادی که به پهلو یا به پشت می‌خوابند ارتفاعی کاملاً متعادل دارد.',
        dimensions: '۵۰×۷۰ سانتی‌متر (بسته دو عددی)',
        material: 'الیاف توپی میکروژل نانو، رویه کتان تنفس‌پذیر ۲۳۰ نخ',
        features: 'قابل شستشو در ماشین لباسشویی، ضد حساسیت و ضد کنه، دوخت مغزی‌دوزی مقاوم',
        price: 2450000,
        stockStatus: 'in_stock',
        stockQuantity: 35,
        isFeatured: 1,
        sortOrder: 3,
        viewCount: 96,
        images: ['/src/assets/images/product_pillow_memory_1795699970843.jpg'],
        specs: [
          ['ابعاد', '۵۰ × ۷۰ سانتی‌متر'],
          ['وزن هر بالش', '۱۱۰۰ گرم'],
          ['نوع پرکننده', 'الیاف میکروژل سیلیکونیزه'],
          ['قابلیت شستشو', 'تا دمای ۴۰ درجه سانتی‌گراد'],
        ],
      },
      {
        categoryId: Number(duvetCat.lastInsertRowid),
        brandId: Number(b3.lastInsertRowid),
        name: 'سرویس روتختی ۶ تکه کتان ساتین مدل آسمان نیلگون',
        slug: 'nilgoon-sky-sateen-duvet-set',
        sku: 'DUV-NS-400',
        shortDescription: 'سرویس دونفره ۴۰۰ نخ با بافت ساتین لطیف در ترکیب سفید برفی و آبی آسمانی',
        description:
          'سرویس روتختی آسمان نیلگون از نخ پنبه شانه‌شده بلندالیاف با تراکم ۴۰۰ شانه بافته شده است. این بافت هم نرمی و درخشش ملایمی دارد و هم گردش هوا را به خوبی برقرار می‌کند تا در تمام فصول دمای بدن متعادل بماند.',
        dimensions: 'کاور لحاف ۲۰۰×۲۲۰ · ملحفه کش‌دوز ۱۶۰×۲۰۰ · ۴ عدد روبالشی ۵۰×۷۰',
        material: '۱۰۰٪ پنبه مصری با بافت ساتین (Sateen Cotton)',
        features: 'ثبات رنگ در شستشوی مکرر، زیپ مخفی باکیفیت، بسته‌بندی پارچه‌ای قابل استفاده مجدد',
        price: 6900000,
        stockStatus: 'in_stock',
        stockQuantity: 18,
        isFeatured: 1,
        sortOrder: 4,
        viewCount: 134,
        images: [
          '/src/assets/images/product_duvet_sky_1795699971673.jpg',
          '/src/assets/images/hero_luxury_bedroom_1795699969658.jpg',
        ],
        specs: [
          ['تراکم بافت', '۴۰۰ نخ در اینچ مربع'],
          ['تعداد تکه‌ها', '۶ تکه کامل دونفره'],
          ['جنس پارچه', '۱۰۰٪ نخ پنبه طبیعی'],
          ['رنگ‌بندی', 'سفید خالص و آبی آسمانی'],
        ],
      },
      {
        categoryId: Number(sheetCat.lastInsertRowid),
        brandId: Number(b3.lastInsertRowid),
        name: 'ست ملحفه کش‌دوز کتان خنک مدل نسیم',
        slug: 'nasim-fitted-cotton-sheet-set',
        sku: 'SHT-NS-160',
        shortDescription: 'ملحفه کش‌دوز عمیق مناسب تشک‌های تا ارتفاع ۳۵ سانتی‌متر به همراه دو روبالشی',
        description:
          'اگر از جابه‌جا شدن ملحفه روی تشک خسته شده‌اید، ست ملحفه کش‌دوز نسیم با کش دورتادور ضخیم و دیواره ۳۸ سانتی‌متری کاملاً روی تشک قفل می‌شود. پارچه کتان خالص بدون ایجاد الکتریسیته ساکن و پرزدهی.',
        dimensions: '۱۶۰×۲۰۰ + دیواره ۳۸ سانتی‌متر (دونفره) و ۹۰×۲۰۰ (تک‌نفره)',
        material: 'کتان ۱۰۰٪ پنبه با تکمیل نرم‌کننده طبیعی',
        features: 'کش‌پهن دورتادور، بدون آبرفت، تنفس‌پذیری بالا در فصل گرم',
        price: 2150000,
        stockStatus: 'in_stock',
        stockQuantity: 28,
        isFeatured: 0,
        sortOrder: 5,
        viewCount: 64,
        images: ['/src/assets/images/product_duvet_sky_1795699971673.jpg'],
        specs: [
          ['عمق دیواره تشک', 'مناسب تشک‌های ۲۰ تا ۳۵ سانتی‌متری'],
          ['اقلام همراه', '۱ ملحفه کش‌دوز + ۲ روبالشی'],
          ['نوع بافت', 'تار و پود کتان تنفس‌پذیر'],
        ],
      },
      {
        categoryId: Number(blanketCat.lastInsertRowid),
        brandId: Number(b1.lastInsertRowid),
        name: 'پتوی بافت وافل پنبه‌ای چهارفصل مدل آبی کرانه',
        slug: 'karane-waffle-cotton-blanket',
        sku: 'BLK-KW-220',
        shortDescription: 'پتوی سبک و تنفس‌پذیر با بافت لانه‌زنبوری (وافل) در ترکیب آبی و سفید',
        description:
          'پتوی بافت وافل آبی کرانه با الهام از طراحی اسکاندیناوی، گزینه‌ای ایده‌آل برای پوشش چهارفصل روی تخت یا مبل است. بافت حفره‌دار آن گرمای متعادل ایجاد کرده و مانع تعریق می‌شود.',
        dimensions: '۲۰۰×۲۲۰ سانتی‌متر (دونفره)',
        material: '۱۰۰٪ پنبه ارگانیک بدون الیاف مصنوعی',
        features: 'سبک و کم‌حجم، شستشوی آسان، لبه دوزی مقاوم و ضد ریش‌ریش شدن',
        price: 3400000,
        stockStatus: 'in_stock',
        stockQuantity: 21,
        isFeatured: 1,
        sortOrder: 6,
        viewCount: 89,
        images: ['/src/assets/images/product_blanket_knit_1795699969636.jpg'],
        specs: [
          ['ابعاد', '۲۰۰ × ۲۲۰ سانتی‌متر'],
          ['وزن', '۱۴۵۰ گرم'],
          ['نوع بافت', 'وافل (لانه‌زنبوری) برجسته'],
          ['کاربرد', 'چهارفصل و روانداز دکوراتیو'],
        ],
      },
      {
        categoryId: Number(protectorCat.lastInsertRowid),
        brandId: Number(b1.lastInsertRowid),
        name: 'محافظ تشک ضدآب و تنفس‌پذیر کتان دوزی‌شده مدل سپر خواب',
        slug: 'separ-khab-waterproof-protector',
        sku: 'PRT-SK-160',
        shortDescription: 'لایه محافظ کاملاً بی‌صدا با رویه کتان لوزی‌دوزی‌شده و ممبران ضد نفوذ مایعات',
        description:
          'محافظ تشک سپر خواب از نفوذ هرگونه رطوبت، لکه و گردوغبار به بافت تشک جلوگیری می‌کند و در عین حال با لایه ممبران میکروپروس اجازه عبور هوا را می‌دهد. بدون صدای خش‌خش پلاستیک هنگام غلت زدن.',
        dimensions: '۱۶۰×۲۰۰ · ۱۸۰×۲۰۰ · ۹۰×۲۰۰ سانتی‌متر',
        material: 'رویه کتان کوبلن لوزی‌دوزی شده + لایه زیرین TPU بی‌صدا و ضدآب',
        features: 'ضدآب ۱۰۰٪، بدون ایجاد صدا، کش‌دوزی چهارگوشه مستحکم، قابل شستشو',
        price: 1680000,
        stockStatus: 'low_stock',
        stockQuantity: 4,
        isFeatured: 0,
        sortOrder: 7,
        viewCount: 77,
        images: ['/src/assets/images/product_protector_cotton_1795699972542.jpg'],
        specs: [
          ['ضدآب بودن', '۱۰۰٪ مقاوم در برابر نفوذ مایعات'],
          ['لایه عایق', 'ممبران TPU تنفس‌پذیر و بی‌صدا'],
          ['نحوه نصب', 'کش‌های پهن در چهار گوشه یا کش‌دوز کامل'],
        ],
      },
      {
        categoryId: Number(kidsCat.lastInsertRowid),
        brandId: Number(b4.lastInsertRowid),
        name: 'سرویس لحاف و روتختی ارگانیک کودک مدل ابر آسمانی',
        slug: 'abre-asemani-kids-bedding',
        sku: 'KID-AA-130',
        shortDescription: 'سرویس کامل تخت کودک و نوجوان با طرح برجسته‌دوزی ابر و رنگ آبی پاستلی ملایم',
        description:
          'طراحی‌شده ویژه پوست حساس کودکان؛ سرویس ابر آسمانی از پنبه ارگانیک فاقد رنگ‌های شیمیایی مضر تولید شده است. لحاف سبک و گرم با دوخت سه‌بعدی طرح ابر به همراه کوسن ابری و روبالشی استاندارد کودک.',
        dimensions: 'لحاف ۱۱۰×۱۴۰ · ملحفه ۸۰×۱۳۰ · روبالشی ۳۵×۴۵ · کوسن ابر',
        material: '۱۰۰٪ پنبه ارگانیک تاییدشده و الیاف ضدآلرژی ویسکوز',
        features: 'فاقد پرز و حساسیت، رنگ‌آمیزی گیاهی، شستشوی مکرر بدون تغییر فرم',
        price: 4200000,
        stockStatus: 'in_stock',
        stockQuantity: 11,
        isFeatured: 1,
        sortOrder: 8,
        viewCount: 105,
        images: ['/src/assets/images/product_kids_bedding_1795699973341.jpg'],
        specs: [
          ['گروه سنی', 'نوزاد و کودک (۱ تا ۷ سال)'],
          ['تعداد تکه', '۴ تکه به همراه کوسن ابر'],
          ['استاندارد بهداشتی', 'ضدآلرژی و بدون مواد شیمیایی'],
        ],
      },
    ];

    for (const p of sampleProducts) {
      const res = insertProduct.run(
        p.categoryId,
        p.brandId,
        p.name,
        p.slug,
        p.sku,
        p.shortDescription,
        p.description,
        p.dimensions,
        p.material,
        p.features,
        p.price,
        p.stockStatus,
        p.stockQuantity,
        p.isFeatured,
        p.sortOrder,
        p.viewCount
      );
      const productId = Number(res.lastInsertRowid);
      p.images.forEach((imgUrl, idx) => {
        insertImage.run(productId, imgUrl, p.name, idx === 0 ? 1 : 0, idx + 1);
      });
      p.specs.forEach(([k, v], idx) => {
        insertSpec.run(productId, k, v, idx + 1);
      });
    }
  }
}
