import {Eye, Star} from 'lucide-react';
import type {ProductListItem} from '../types';
import {formatNumberFa, formatPriceToman, getStockLabel, toPersianDigits} from '../utils/format';
import {SafeImage} from './SafeImage';

interface ProductCardProps {
  product: ProductListItem;
  onNavigate: (path: string) => void;
}

export function ProductCard({product, onNavigate}: ProductCardProps) {
  const stock = getStockLabel(product.stock_status);
  const stockColor =
    stock.tone === 'emerald'
      ? 'text-emerald-700'
      : stock.tone === 'amber'
        ? 'text-amber-700'
        : 'text-rose-700';

  return (
    <article
      onClick={() => onNavigate(`/product/${product.id}`)}
      className="group bg-white border border-slate-200/90 rounded-xl overflow-hidden flex flex-col cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md hover:border-sky-200"
    >
      <div className="relative aspect-[4/3] w-full bg-sky-50/40 overflow-hidden">
        <SafeImage
          src={product.primary_image}
          alt={product.name}
          fallbackTitle={product.name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </div>

      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between gap-3">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5 truncate">
            <span>{product.category_name}</span>
            {product.brand_name && (
              <>
                <span aria-hidden="true">·</span>
                <span>{product.brand_name}</span>
              </>
            )}
            {product.is_featured === 1 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-sky-700 font-medium">منتخب</span>
              </>
            )}
          </div>

          <h3 className="text-base font-semibold text-slate-900 leading-snug line-clamp-2 group-hover:text-sky-700 transition-colors">
            {product.name}
          </h3>

          {product.short_description && (
            <p className="mt-1.5 text-xs text-slate-500 leading-relaxed line-clamp-2">
              {product.short_description}
            </p>
          )}
        </div>

        <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className={`font-medium ${stockColor}`}>{stock.text}</span>
            <div className="flex items-center gap-3 text-slate-500 tabular-nums">
              <span className="inline-flex items-center gap-1" title="تعداد بازدید">
                <Eye className="w-3.5 h-3.5 text-slate-400" />
                {formatNumberFa(product.view_count)}
              </span>
              <span className="inline-flex items-center gap-1 text-slate-700 font-medium">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                {product.rating_count > 0
                  ? `${toPersianDigits(product.avg_rating)} (${formatNumberFa(product.rating_count)})`
                  : 'بدون امتیاز'}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm sm:text-base font-bold text-slate-900 tabular-nums">
              {formatPriceToman(product.price)}
            </span>
            <span className="text-xs font-medium text-sky-700 group-hover:text-sky-800 whitespace-nowrap shrink-0">
              مشاهده مشخصات ←
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}
