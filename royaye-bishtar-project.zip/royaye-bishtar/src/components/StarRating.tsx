import {useState} from 'react';
import {Star} from 'lucide-react';

interface StarRatingProps {
  value: number;
  interactive?: boolean;
  onChange?: (score: number) => void;
  size?: 'sm' | 'md' | 'lg';
}

export function StarRating({
  value,
  interactive = false,
  onChange,
  size = 'md',
}: StarRatingProps) {
  const [hoverScore, setHoverScore] = useState<number | null>(null);
  const activeValue = hoverScore ?? value;

  const sizeClass =
    size === 'sm' ? 'w-3.5 h-3.5' : size === 'lg' ? 'w-6 h-6' : 'w-4 h-4';

  return (
    <div
      className="inline-flex items-center gap-1"
      dir="ltr"
      onMouseLeave={() => interactive && setHoverScore(null)}
    >
      {[1, 2, 3, 4, 5].map((star) => {
        const filled = star <= Math.round(activeValue);
        const half = !filled && star - 0.5 <= activeValue;

        if (interactive) {
          return (
            <button
              key={star}
              type="button"
              onClick={() => onChange?.(star)}
              onMouseEnter={() => setHoverScore(star)}
              aria-label={`امتیاز ${star} ستاره`}
              className="p-0.5 transition-transform duration-150 hover:scale-110 focus-visible:outline-2 focus-visible:outline-sky-600 rounded cursor-pointer"
            >
              <Star
                className={`${sizeClass} ${
                  filled ? 'fill-amber-400 text-amber-400' : 'text-slate-300 fill-transparent'
                }`}
              />
            </button>
          );
        }

        return (
          <Star
            key={star}
            className={`${sizeClass} ${
              filled || half
                ? 'fill-amber-400 text-amber-400'
                : 'text-slate-200 fill-slate-100'
            }`}
          />
        );
      })}
    </div>
  );
}
