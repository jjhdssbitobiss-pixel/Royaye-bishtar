import {useState} from 'react';
import {Menu, X} from 'lucide-react';
import {useAuth} from '../context/AuthContext';

interface HeaderProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export function Header({currentPath, onNavigate}: HeaderProps) {
  const {user, isAuthenticated, isAdmin} = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    {label: 'صفحه اصلی', path: '/'},
    {label: 'کاتالوگ محصولات', path: '/catalog'},
    {label: 'دسته‌بندی‌ها', path: '/categories'},
    ...(isAdmin ? [{label: 'پنل مدیریت', path: '/admin'}] : [{label: 'راهنمای انتخاب', path: '/catalog?featured=1'}]),
  ];

  const handleNav = (path: string) => {
    setMobileOpen(false);
    onNavigate(path);
  };

  const isActive = (path: string) => {
    if (path === '/') return currentPath === '/';
    return currentPath.startsWith(path.split('?')[0]);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('/')}
          className="text-lg sm:text-xl font-extrabold tracking-tight text-sky-800 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-sky-600 rounded"
        >
          رویای بیشتر
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          {navItems.map((item) => (
            <button
              key={item.path}
              type="button"
              onClick={() => handleNav(item.path)}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                isActive(item.path)
                  ? 'text-sky-700 border-sky-600 font-semibold'
                  : 'border-transparent hover:text-sky-700 hover:border-sky-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          {isAuthenticated ? (
            <button
              type="button"
              onClick={() => handleNav(isAdmin ? '/admin' : '/profile')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer max-w-[11rem] truncate"
            >
              {user?.full_name}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleNav('/auth')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              ورود / ثبت‌نام
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label={mobileOpen ? 'بستن منو' : 'باز کردن منو'}
            className="md:hidden p-2 text-slate-700 hover:bg-sky-50 rounded-lg cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 flex flex-col gap-1">
          {navItems.map((item) => (
            <button
              key={item.path}
              type="button"
              onClick={() => handleNav(item.path)}
              className={`w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                isActive(item.path)
                  ? 'bg-sky-50 text-sky-800 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              {item.label}
            </button>
          ))}
          {isAuthenticated && (
            <button
              type="button"
              onClick={() => handleNav('/profile')}
              className="w-full text-right px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              پروفایل و نظرات من
            </button>
          )}
        </div>
      )}
    </header>
  );
}
