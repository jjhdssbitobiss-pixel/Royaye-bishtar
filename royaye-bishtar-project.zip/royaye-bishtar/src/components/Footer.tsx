interface FooterProps {
  onNavigate: (path: string) => void;
}

export function Footer({onNavigate}: FooterProps) {
  return (
    <footer className="bg-slate-50 border-t border-slate-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <h2 className="text-lg font-extrabold text-sky-800 mb-3">رویای بیشتر</h2>
            <p className="text-sm text-slate-600 leading-relaxed max-w-sm">
              مرجع تخصصی معرفی و بررسی کالای خواب استاندارد؛ تشک‌های طبی ارتوپدیک، بالش‌های ارگونومیک، روتختی کتان و منسوجات ضدحساسیت برای تجربه‌ای آرام و سالم از خواب شبانه.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-3">دسترسی سریع</h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/catalog')}
                  className="hover:text-sky-700 transition-colors cursor-pointer"
                >
                  کاتالوگ کامل محصولات
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/categories')}
                  className="hover:text-sky-700 transition-colors cursor-pointer"
                >
                  دسته‌بندی‌های کالای خواب
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/catalog?sort=rating')}
                  className="hover:text-sky-700 transition-colors cursor-pointer"
                >
                  برترین محصولات از نگاه کاربران
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/auth')}
                  className="hover:text-sky-700 transition-colors cursor-pointer"
                >
                  ورود و حساب کاربری
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-3">تعهد کیفیت و اصالت</h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>اطلاعات فنی شفاف و دقیق برای انتخاب آگاهانه</li>
              <li>بررسی و تایید نظرات واقعی خریداران و مشتریان</li>
              <li>تضمین الیاف طبیعی، ضد حساسیت و استاندارد ارگونومیک</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>تمامی حقوق مادی و معنوی برای فروشگاه و کاتالوگ تخصصی کالای خواب رویای بیشتر محفوظ است.</p>
          <p>طراحی‌شده برای انتخابی مطمئن و خوابی آرام</p>
        </div>
      </div>
    </footer>
  );
}
