import {useCallback, useEffect, useState} from 'react';
import {Activity, Ban, CheckCircle, Star, X} from 'lucide-react';
import {apiRequest} from '../../api/client';
import type {ReviewItem, User} from '../../types';
import {formatDateFa, formatNumberFa, getReviewStatusLabel, toPersianDigits} from '../../utils/format';

interface AdminUserRow extends User {
  review_count: number;
  rating_count: number;
  created_at: string;
}

interface UserActivityData {
  user: User;
  reviews: ReviewItem[];
  ratings: {id: number; product_name: string; score: number; updated_at: string}[];
}

interface AdminUsersTabProps {
  onDataChanged: () => void;
}

export function AdminUsersTab({onDataChanged}: AdminUsersTabProps) {
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [activityModal, setActivityModal] = useState<UserActivityData | null>(null);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{users: AdminUserRow[]}>('/api/admin/users');
      setUsers(res.users);
    } catch {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const handleToggleBlock = async (userId: number, block: boolean) => {
    try {
      await apiRequest(`/api/admin/users/${userId}/block`, {
        method: 'PATCH',
        body: JSON.stringify({is_blocked: block}),
      });
      await loadUsers();
      onDataChanged();
    } catch {
      // ignore
    }
  };

  const openActivity = async (userId: number) => {
    try {
      const res = await apiRequest<UserActivityData>(`/api/admin/users/${userId}/activity`);
      setActivityModal(res);
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
            <tr>
              <th className="text-right font-semibold px-4 py-3">نام و ایمیل</th>
              <th className="text-right font-semibold px-4 py-3">نقش</th>
              <th className="text-right font-semibold px-4 py-3">تماس / شهر</th>
              <th className="text-right font-semibold px-4 py-3">فعالیت</th>
              <th className="text-right font-semibold px-4 py-3">وضعیت</th>
              <th className="text-left font-semibold px-4 py-3">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                  در حال بارگذاری...
                </td>
              </tr>
            ) : (
              users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/70">
                  <td className="px-4 py-3">
                    <div className="font-bold text-slate-900">{u.full_name}</div>
                    <div className="text-xs text-slate-500" dir="ltr">
                      {u.email}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs font-semibold text-slate-700">
                    {u.role_display_name}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600">
                    <div>{u.phone || '—'}</div>
                    <div className="text-slate-400">{u.city || '—'}</div>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600 tabular-nums">
                    {formatNumberFa(u.review_count)} نظر · {formatNumberFa(u.rating_count)} امتیاز
                  </td>
                  <td className="px-4 py-3 text-xs font-semibold">
                    {u.is_blocked ? (
                      <span className="text-rose-700">مسدود</span>
                    ) : (
                      <span className="text-emerald-700">فعال</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-left whitespace-nowrap">
                    <div className="inline-flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => openActivity(u.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <Activity className="w-3.5 h-3.5" />
                        فعالیت‌ها
                      </button>
                      {u.role_name !== 'admin' && (
                        <button
                          type="button"
                          onClick={() => handleToggleBlock(u.id, !u.is_blocked)}
                          className={`inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg cursor-pointer ${
                            u.is_blocked
                              ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
                              : 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                          }`}
                        >
                          {u.is_blocked ? (
                            <>
                              <CheckCircle className="w-3.5 h-3.5" />
                              رفع مسدودی
                            </>
                          ) : (
                            <>
                              <Ban className="w-3.5 h-3.5" />
                              مسدودسازی
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {activityModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  فعالیت کاربر: {activityModal.user.full_name}
                </h3>
                <p className="text-xs text-slate-500">{activityModal.user.email}</p>
              </div>
              <button
                type="button"
                onClick={() => setActivityModal(null)}
                className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6">
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-3">
                  امتیازهای ثبت‌شده ({formatNumberFa(activityModal.ratings.length)})
                </h4>
                {activityModal.ratings.length === 0 ? (
                  <p className="text-xs text-slate-500">امتیازی ثبت نشده است.</p>
                ) : (
                  <div className="space-y-2">
                    {activityModal.ratings.map((rt) => (
                      <div
                        key={rt.id}
                        className="flex items-center justify-between border border-slate-100 rounded-lg px-3 py-2 text-xs"
                      >
                        <span className="font-medium text-slate-800">{rt.product_name}</span>
                        <span className="inline-flex items-center gap-1 font-bold text-amber-700 tabular-nums">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          {toPersianDigits(rt.score)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-3">
                  نظرات ثبت‌شده ({formatNumberFa(activityModal.reviews.length)})
                </h4>
                {activityModal.reviews.length === 0 ? (
                  <p className="text-xs text-slate-500">نظری ثبت نشده است.</p>
                ) : (
                  <div className="space-y-3">
                    {activityModal.reviews.map((rv) => {
                      const st = getReviewStatusLabel(rv.status);
                      return (
                        <div key={rv.id} className="border border-slate-200 rounded-lg p-3 space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-900">{rv.product_name}</span>
                            <span className="text-slate-500">
                              {st.text} · {formatDateFa(rv.created_at)}
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 leading-relaxed">{rv.comment}</p>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
