import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {Edit3, Plus, Trash2} from 'lucide-react';
import {apiRequest, ApiError} from '../../api/client';
import type {Brand, Category} from '../../types';
import {formatNumberFa} from '../../utils/format';
import {SafeImage} from '../SafeImage';
import {AdminImagePicker} from './AdminImagePicker';

interface AdminCategoriesTabProps {
  onDataChanged: () => void;
}

export function AdminCategoriesTab({onDataChanged}: AdminCategoriesTabProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [error, setError] = useState('');

  // Category Form
  const [editingCatId, setEditingCatId] = useState<number | null>(null);
  const [catName, setCatName] = useState('');
  const [parentId, setParentId] = useState('');
  const [catDesc, setCatDesc] = useState('');
  const [catImg, setCatImg] = useState('');
  const [catSort, setCatSort] = useState('0');
  const [catActive, setCatActive] = useState(true);

  // Brand Form
  const [brandName, setBrandName] = useState('');
  const [brandCountry, setBrandCountry] = useState('ایران');
  const [brandDesc, setBrandDesc] = useState('');

  const loadData = useCallback(async () => {
    try {
      const [cRes, bRes] = await Promise.all([
        apiRequest<{categories: Category[]}>('/api/admin/categories'),
        apiRequest<{brands: Brand[]}>('/api/admin/brands'),
      ]);
      setCategories(cRes.categories);
      setBrands(bRes.brands);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const resetCatForm = () => {
    setEditingCatId(null);
    setCatName('');
    setParentId('');
    setCatDesc('');
    setCatImg('');
    setCatSort('0');
    setCatActive(true);
  };

  const handleSaveCategory = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    const payload = {
      name: catName,
      parent_id: parentId ? Number(parentId) : null,
      description: catDesc,
      image_url: catImg,
      sort_order: Number(catSort),
      is_active: catActive,
    };

    try {
      if (editingCatId) {
        await apiRequest(`/api/admin/categories/${editingCatId}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiRequest('/api/admin/categories', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }
      resetCatForm();
      await loadData();
      onDataChanged();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'خطا در ذخیره دسته‌بندی.');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    setError('');
    try {
      await apiRequest(`/api/admin/categories/${id}`, {method: 'DELETE'});
      await loadData();
      onDataChanged();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'امکان حذف دسته‌بندی وجود ندارد.');
    }
  };

  const handleCreateBrand = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await apiRequest('/api/admin/brands', {
        method: 'POST',
        body: JSON.stringify({name: brandName, country: brandCountry, description: brandDesc}),
      });
      setBrandName('');
      setBrandDesc('');
      await loadData();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'خطا در افزودن برند.');
    }
  };

  const handleDeleteBrand = async (id: number) => {
    try {
      await apiRequest(`/api/admin/brands/${id}`, {method: 'DELETE'});
      await loadData();
    } catch {
      // ignore
    }
  };

  const parentCandidates = categories.filter((c) => c.parent_id === null && c.id !== editingCatId);

  return (
    <div className="space-y-8">
      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm p-3 rounded-lg">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Create / Edit Category Form */}
        <form
          onSubmit={handleSaveCategory}
          className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
        >
          <h3 className="text-base font-bold text-slate-900">
            {editingCatId ? 'ویرایش دسته‌بندی' : 'ایجاد دسته‌بندی یا زیردسته جدید'}
          </h3>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">نام دسته‌بندی</label>
            <input
              type="text"
              required
              value={catName}
              onChange={(e) => setCatName(e.target.value)}
              placeholder="مثال: بالش طبی یا روتختی مخمل"
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              دسته والد (برای ایجاد زیردسته انتخاب کنید)
            </label>
            <select
              value={parentId}
              onChange={(e) => setParentId(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            >
              <option value="">دسته اصلی (بدون والد)</option>
              {parentCandidates.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">توضیحات</label>
            <textarea
              rows={2}
              value={catDesc}
              onChange={(e) => setCatDesc(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">تصویر دسته‌بندی</label>
            <AdminImagePicker onUploaded={(url) => setCatImg(url)} buttonLabel="آپلود تصویر دسته" />
            <input
              type="text"
              dir="ltr"
              value={catImg}
              onChange={(e) => setCatImg(e.target.value)}
              placeholder="/uploads/... یا /src/assets/..."
              className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-left"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 items-center">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">ترتیب</label>
              <input
                type="number"
                value={catSort}
                onChange={(e) => setCatSort(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm tabular-nums"
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-700 pt-4 cursor-pointer">
              <input
                type="checkbox"
                checked={catActive}
                onChange={(e) => setCatActive(e.target.checked)}
                className="w-4 h-4 accent-sky-700"
              />
              <span>فعال</span>
            </label>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg cursor-pointer"
            >
              {editingCatId ? 'ذخیره تغییرات' : 'ایجاد دسته‌بندی'}
            </button>
            {editingCatId && (
              <button
                type="button"
                onClick={resetCatForm}
                className="px-4 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-lg cursor-pointer"
              >
                انصراف
              </button>
            )}
          </div>
        </form>

        {/* Categories List */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 font-bold text-sm text-slate-900">
            فهرست دسته‌بندی‌ها و زیردسته‌ها ({formatNumberFa(categories.length)})
          </div>
          <div className="divide-y divide-slate-100">
            {categories.map((cat) => (
              <div key={cat.id} className="px-5 py-3.5 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-lg overflow-hidden bg-sky-50 border border-slate-100 shrink-0">
                    <SafeImage src={cat.image_url} alt={cat.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-slate-900 truncate">
                      {cat.parent_id ? `↳ ${cat.name}` : cat.name}
                    </div>
                    <div className="text-xs text-slate-500">
                      {cat.parent_name ? `زیردسته ${cat.parent_name}` : 'دسته اصلی'} ·{' '}
                      {formatNumberFa(cat.product_count ?? 0)} محصول ·{' '}
                      {cat.is_active ? 'فعال' : 'غیرفعال'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCatId(cat.id);
                      setCatName(cat.name);
                      setParentId(cat.parent_id ? String(cat.parent_id) : '');
                      setCatDesc(cat.description || '');
                      setCatImg(cat.image_url || '');
                      setCatSort(String(cat.sort_order));
                      setCatActive(cat.is_active === 1);
                    }}
                    className="p-1.5 text-sky-700 hover:bg-sky-50 rounded-lg cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteCategory(cat.id)}
                    className="p-1.5 text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Brands Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <h3 className="text-base font-bold text-slate-900">مدیریت برندهای تولیدکننده</h3>
        <form onSubmit={handleCreateBrand} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">نام برند</label>
            <input
              type="text"
              required
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">کشور تولیدکننده</label>
            <input
              type="text"
              value={brandCountry}
              onChange={(e) => setBrandCountry(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">توضیح کوتاه</label>
            <input
              type="text"
              value={brandDesc}
              onChange={(e) => setBrandDesc(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 py-2 px-4 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            افزودن برند
          </button>
        </form>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {brands.map((b) => (
            <div key={b.id} className="border border-slate-200 rounded-lg p-3 flex items-center justify-between">
              <div>
                <div className="text-sm font-bold text-slate-900">{b.name}</div>
                <div className="text-xs text-slate-500">
                  {b.country || 'نامشخص'} · {formatNumberFa(b.product_count ?? 0)} محصول
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleDeleteBrand(b.id)}
                className="p-1 text-rose-600 hover:bg-rose-50 rounded cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
