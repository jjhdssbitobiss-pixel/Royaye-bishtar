import {useCallback, useEffect, useState} from 'react';
import {Check, Star, Trash2, X} from 'lucide-react';
import {apiRequest} from '../../api/client';
import type {ReviewItem} from '../../types';
import {formatDateFa, formatNumberFa, getReviewStatusLabel, toPersianDigits} from '../../utils/format';

interface RatingSummaryRow {
  id: number;
  name: string;
  avg_rating: number;
  rating_count: number;
  review_count: number;
}

interface AdminReviewsTabProps {
  onDataChanged: () => void;
}

export function AdminReviewsTab({onDataChanged}: AdminReviewsTabProps) {
  const [statusFilter, setStatusFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [ratingSummary, setRatingSummary] = useState<RatingSummaryRow[]>([]);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [loading, setLoading] = useState(true);

  const loadReviews = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{reviews: ReviewItem[]; ratingSummary: RatingSummaryRow[]}>(
        `/api/admin/reviews?status=${statusFilter}`
      );
      setReviews(res.reviews);
      setRatingSummary(res.ratingSummary);
    } catch {
      setReviews([]);
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    loadReviews();
  }, [loadReviews]);

  const handleModerate = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await apiRequest(`/api/admin/reviews/${id}/moderate`, {
        method: 'PATCH',
        body: JSON.stringify({status, admin_note: notes[id] || ''}),
      });
      await loadReviews();
      onDataChanged();
    } catch {
      // ignore
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await apiRequest(`/api/admin/reviews/${id}`, {method: 'DELETE'});
      await loadReviews();
      onDataChanged();
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {(
            [
              ['pending', 'در انتظار تایید'],
              ['approved', 'تایید شده'],
              ['rejected', 'رد شده'],
              ['all', 'همه نظرات'],
            ] as const
          ).map(([val, label]) => (
            <button
              key={val}
              type="button"
              onClick={() => setStatusFilter(val)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                statusFilter === val ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="h-40 rounded-xl bg-slate-100 animate-pulse" />
      ) : reviews.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
          نظری در این بخش وجود ندارد.
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((rv) => {
            const st = getReviewStatusLabel(rv.status);
            return (
              <div key={rv.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-sm font-bold text-slate-900">
                      {rv.product_name}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span>{rv.user_name}</span>
                      <span aria-hidden="true">·</span>
                      <span dir="ltr">{rv.user_email}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateFa(rv.created_at)}</span>
                      {rv.user_rating && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-slate-800 font-semibold tabular-nums">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            {toPersianDigits(rv.user_rating)}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <span
                    className={`text-xs font-semibold ${
                      st.tone === 'emerald'
                        ? 'text-emerald-700'
                        : st.tone === 'amber'
                          ? 'text-amber-700'
                          : 'text-rose-700'
                    }`}
                  >
                    {st.text}
                  </span>
                </div>

                {rv.title && <div className="text-sm font-bold text-slate-800">{rv.title}</div>}
                <p className="text-sm text-slate-700 leading-relaxed">{rv.comment}</p>

                <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <input
                    type="text"
                    value={notes[rv.id] ?? rv.admin_note ?? ''}
                    onChange={(e) => setNotes((prev) => ({...prev, [rv.id]: e.target.value}))}
                    placeholder="یادداشت مدیر (اختیاری)..."
                    className="flex-1 border border-slate-200 rounded-lg px-3 py-1.5 text-xs"
                  />
                  <div className="flex items-center gap-2 shrink-0">
                    {rv.status !== 'approved' && (
                      <button
                        type="button"
                        onClick={() => handleModerate(rv.id, 'approved')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        تایید و انتشار
                      </button>
                    )}
                    {rv.status !== 'rejected' && (
                      <button
                        type="button"
                        onClick={() => handleModerate(rv.id, 'rejected')}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                        رد کردن
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDelete(rv.id)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      حذف
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Product Ratings Summary */}
      {ratingSummary.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 text-sm font-bold text-slate-900">
            خلاصه امتیازهای ثبت‌شده محصولات
          </div>
          <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 text-xs text-slate-500">
              <tr>
                <th className="text-right font-semibold px-4 py-2.5">محصول</th>
                <th className="text-right font-semibold px-4 py-2.5">میانگین امتیاز</th>
                <th className="text-right font-semibold px-4 py-2.5">تعداد امتیاز</th>
                <th className="text-right font-semibold px-4 py-2.5">تعداد نظرات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {ratingSummary.map((row) => (
                <tr key={row.id}>
                  <td className="px-4 py-2.5 font-medium text-slate-900">{row.name}</td>
                  <td className="px-4 py-2.5 tabular-nums font-bold text-amber-700">
                    {toPersianDigits(row.avg_rating)} ★
                  </td>
                  <td className="px-4 py-2.5 tabular-nums text-slate-600">
                    {formatNumberFa(row.rating_count)}
                  </td>
                  <td className="px-4 py-2.5 tabular-nums text-slate-600">
                    {formatNumberFa(row.review_count)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}
    </div>
  );
}
