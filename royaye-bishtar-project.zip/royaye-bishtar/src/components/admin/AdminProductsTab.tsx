import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {Edit3, Plus, Search, Star, Trash2, X} from 'lucide-react';
import {apiRequest, ApiError} from '../../api/client';
import type {Brand, Category, ProductImage, ProductListItem, ProductSpecification} from '../../types';
import {formatNumberFa, formatPriceToman, getStockLabel, toPersianDigits} from '../../utils/format';
import {SafeImage} from '../SafeImage';
import {AdminImagePicker} from './AdminImagePicker';

interface ProductFormImage {
  image_url: string;
  alt_text: string;
  is_primary: boolean;
}

interface ProductFormSpec {
  spec_key: string;
  spec_value: string;
}

interface AdminProductsTabProps {
  onDataChanged: () => void;
}

export function AdminProductsTab({onDataChanged}: AdminProductsTabProps) {
  const [products, setProducts] = useState<ProductListItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // Form fields
  const [name, setName] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [brandId, setBrandId] = useState('');
  const [sku, setSku] = useState('');
  const [price, setPrice] = useState('0');
  const [stockStatus, setStockStatus] = useState('in_stock');
  const [stockQuantity, setStockQuantity] = useState('10');
  const [sortOrder, setSortOrder] = useState('0');
  const [isActive, setIsActive] = useState(true);
  const [isFeatured, setIsFeatured] = useState(false);
  const [shortDescription, setShortDescription] = useState('');
  const [description, setDescription] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [material, setMaterial] = useState('');
  const [features, setFeatures] = useState('');
  const [images, setImages] = useState<ProductFormImage[]>([]);
  const [newImageUrl, setNewImageUrl] = useState('');
  const [specifications, setSpecifications] = useState<ProductFormSpec[]>([]);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [prodRes, catRes, brandRes] = await Promise.all([
        apiRequest<{products: ProductListItem[]}>(
          `/api/admin/products${search.trim() ? `?q=${encodeURIComponent(search.trim())}` : ''}`
        ),
        apiRequest<{categories: Category[]}>('/api/admin/categories'),
        apiRequest<{brands: Brand[]}>('/api/admin/brands'),
      ]);
      setProducts(prodRes.products);
      setCategories(catRes.categories);
      setBrands(brandRes.brands);
    } catch {
      // handled cleanly
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const openCreateModal = () => {
    setEditingId(null);
    setFormError('');
    setName('');
    setCategoryId(categories[0]?.id ? String(categories[0].id) : '');
    setBrandId('');
    setSku('');
    setPrice('');
    setStockStatus('in_stock');
    setStockQuantity('10');
    setSortOrder(String(products.length + 1));
    setIsActive(true);
    setIsFeatured(false);
    setShortDescription('');
    setDescription('');
    setDimensions('');
    setMaterial('');
    setFeatures('');
    setImages([]);
    setNewImageUrl('');
    setSpecifications([{spec_key: '', spec_value: ''}]);
    setModalOpen(true);
  };

  const openEditModal = async (productId: number) => {
    setFormError('');
    try {
      const res = await apiRequest<{
        product: ProductListItem & {description: string};
        images: ProductImage[];
        specifications: ProductSpecification[];
      }>(`/api/admin/products/${productId}`);

      const p = res.product;
      setEditingId(p.id);
      setName(p.name);
      setCategoryId(String(p.category_id));
      setBrandId(p.brand_id ? String(p.brand_id) : '');
      setSku(p.sku || '');
      setPrice(String(p.price));
      setStockStatus(p.stock_status);
      setStockQuantity(String(p.stock_quantity));
      setSortOrder(String(p.sort_order));
      setIsActive(p.is_active === 1);
      setIsFeatured(p.is_featured === 1);
      setShortDescription(p.short_description || '');
      setDescription(p.description || '');
      setDimensions(p.dimensions || '');
      setMaterial(p.material || '');
      setFeatures(p.features || '');
      setImages(
        res.images.map((i) => ({
          image_url: i.image_url,
          alt_text: i.alt_text || p.name,
          is_primary: i.is_primary === 1,
        }))
      );
      setSpecifications(
        res.specifications.length > 0
          ? res.specifications.map((s) => ({spec_key: s.spec_key, spec_value: s.spec_value}))
          : [{spec_key: '', spec_value: ''}]
      );
      setModalOpen(true);
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'خطا در دریافت اطلاعات محصول');
    }
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);

    const payload = {
      name,
      category_id: Number(categoryId),
      brand_id: brandId ? Number(brandId) : null,
      sku,
      price: Number(price),
      stock_status: stockStatus,
      stock_quantity: Number(stockQuantity),
      sort_order: Number(sortOrder),
      is_active: isActive,
      is_featured: isFeatured,
      short_description: shortDescription,
      description,
      dimensions,
      material,
      features,
      images,
      specifications: specifications.filter((s) => s.spec_key.trim() && s.spec_value.trim()),
    };

    try {
      if (editingId) {
        await apiRequest(`/api/admin/products/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiRequest('/api/admin/products', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }
      setModalOpen(false);
      await loadAll();
      onDataChanged();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'خطا در ذخیره محصول.');
    } finally {
      setSaving(false);
    }
  };

  const handleQuickPatch = async (id: number, patch: Record<string, unknown>) => {
    try {
      await apiRequest(`/api/admin/products/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
      });
      await loadAll();
      onDataChanged();
    } catch {
      // ignore
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await apiRequest(`/api/admin/products/${id}`, {method: 'DELETE'});
      await loadAll();
      onDataChanged();
    } catch {
      // ignore
    }
  };

  const addImage = (url: string) => {
    const trimmed = url.trim();
    if (!trimmed) return;
    setImages((prev) => [
      ...prev,
      {image_url: trimmed, alt_text: name || 'تصویر محصول', is_primary: prev.length === 0},
    ]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center bg-white border border-slate-200 rounded-lg px-3 py-2 w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 ml-2 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="جستجوی محصول، کد یا دسته‌بندی..."
            className="w-full text-sm focus:outline-none"
          />
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          افزودن محصول جدید
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
            <tr>
              <th className="text-right font-semibold px-4 py-3">محصول</th>
              <th className="text-right font-semibold px-4 py-3">دسته / برند</th>
              <th className="text-right font-semibold px-4 py-3">قیمت</th>
              <th className="text-right font-semibold px-4 py-3">موجودی</th>
              <th className="text-right font-semibold px-4 py-3">ترتیب</th>
              <th className="text-right font-semibold px-4 py-3">وضعیت</th>
              <th className="text-right font-semibold px-4 py-3">ویژه</th>
              <th className="text-left font-semibold px-4 py-3">عملیات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                  در حال بارگذاری...
                </td>
              </tr>
            ) : products.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                  محصولی یافت نشد.
                </td>
              </tr>
            ) : (
              products.map((p) => {
                const st = getStockLabel(p.stock_status);
                return (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-10 rounded-lg overflow-hidden bg-sky-50 border border-slate-100 shrink-0">
                          <SafeImage src={p.primary_image} alt={p.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900 truncate max-w-[14rem]">{p.name}</div>
                          <div className="text-xs text-slate-500 tabular-nums">
                            {formatNumberFa(p.view_count)} بازدید · {toPersianDigits(p.avg_rating)} ★
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">
                      <div>{p.category_name}</div>
                      {p.brand_name && <div className="text-slate-400">{p.brand_name}</div>}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                      {formatPriceToman(p.price)}
                    </td>
                    <td className="px-4 py-3 text-xs font-medium whitespace-nowrap">
                      <span
                        className={
                          st.tone === 'emerald'
                            ? 'text-emerald-700'
                            : st.tone === 'amber'
                              ? 'text-amber-700'
                              : 'text-rose-700'
                        }
                      >
                        {st.text}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <input
                        type="number"
                        defaultValue={p.sort_order}
                        onBlur={(e) => {
                          const val = Number(e.target.value);
                          if (!Number.isNaN(val) && val !== p.sort_order) {
                            handleQuickPatch(p.id, {sort_order: val});
                          }
                        }}
                        className="w-16 border border-slate-200 rounded px-2 py-1 text-xs text-center tabular-nums"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => handleQuickPatch(p.id, {is_active: p.is_active ? 0 : 1})}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-md cursor-pointer ${
                          p.is_active
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {p.is_active ? 'فعال' : 'غیرفعال'}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => handleQuickPatch(p.id, {is_featured: p.is_featured ? 0 : 1})}
                        className={`p-1.5 rounded-md cursor-pointer ${
                          p.is_featured ? 'text-amber-500 bg-amber-50' : 'text-slate-300 hover:text-slate-500'
                        }`}
                        title="محصول ویژه"
                      >
                        <Star className={`w-4 h-4 ${p.is_featured ? 'fill-amber-400' : ''}`} />
                      </button>
                    </td>
                    <td className="px-4 py-3 text-left whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditModal(p.id)}
                          className="p-1.5 text-sky-700 hover:bg-sky-50 rounded-lg cursor-pointer"
                          title="ویرایش"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(p.id)}
                          className="p-1.5 text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">
                {editingId ? 'ویرایش محصول' : 'افزودن محصول جدید'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-6">
              {formError && (
                <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-lg">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">نام محصول</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">دسته‌بندی</label>
                  <select
                    required
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  >
                    <option value="">انتخاب دسته‌بندی...</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.parent_id ? `— ${c.name}` : c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">برند</label>
                  <select
                    value={brandId}
                    onChange={(e) => setBrandId(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  >
                    <option value="">بدون برند مشخص</option>
                    {brands.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">قیمت (تومان)</label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm tabular-nums"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">وضعیت موجودی</label>
                    <select
                      value={stockStatus}
                      onChange={(e) => setStockStatus(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                    >
                      <option value="in_stock">موجود</option>
                      <option value="low_stock">موجودی محدود</option>
                      <option value="out_of_stock">ناموجود</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">تعداد</label>
                    <input
                      type="number"
                      min={0}
                      value={stockQuantity}
                      onChange={(e) => setStockQuantity(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm tabular-nums"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">کد کالا (SKU)</label>
                  <input
                    type="text"
                    dir="ltr"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-left"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ترتیب نمایش</label>
                  <input
                    type="number"
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm tabular-nums"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6">
                <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 accent-sky-700"
                  />
                  <span>محصول فعال (قابل مشاهده در فروشگاه)</span>
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="w-4 h-4 accent-sky-700"
                  />
                  <span>محصول منتخب و ویژه</span>
                </label>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">معرفی کوتاه</label>
                  <input
                    type="text"
                    value={shortDescription}
                    onChange={(e) => setShortDescription(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">توضیحات کامل</label>
                  <textarea
                    rows={4}
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">ابعاد و سایزبندی</label>
                    <input
                      type="text"
                      value={dimensions}
                      onChange={(e) => setDimensions(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">جنس و مواد اولیه</label>
                    <input
                      type="text"
                      value={material}
                      onChange={(e) => setMaterial(e.target.value)}
                      className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ویژگی‌ها و مزایا (با ویرگول جدا کنید)
                  </label>
                  <input
                    type="text"
                    value={features}
                    onChange={(e) => setFeatures(e.target.value)}
                    placeholder="مثال: ضد حساسیت، قابل شستشو، تنفس‌پذیر"
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>
              </div>

              {/* Multi-Image Manager */}
              <div className="border-t border-slate-200 pt-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900">تصاویر محصول</h4>
                  <AdminImagePicker onUploaded={addImage} buttonLabel="آپلود تصویر جدید" />
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    dir="ltr"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="یا آدرس تصویر را وارد کنید (/uploads/... یا https://...)"
                    className="flex-1 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-left"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      addImage(newImageUrl);
                      setNewImageUrl('');
                    }}
                    className="px-3 py-1.5 bg-slate-800 text-white text-xs font-semibold rounded-lg cursor-pointer"
                  >
                    افزودن لینک
                  </button>
                </div>

                {images.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {images.map((img, idx) => (
                      <div
                        key={idx}
                        className={`border rounded-lg p-2 space-y-2 ${
                          img.is_primary ? 'border-sky-600 bg-sky-50/40' : 'border-slate-200'
                        }`}
                      >
                        <div className="aspect-[4/3] rounded overflow-hidden bg-slate-100">
                          <SafeImage src={img.image_url} alt={img.alt_text} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <button
                            type="button"
                            onClick={() =>
                              setImages((prev) =>
                                prev.map((item, i) => ({...item, is_primary: i === idx}))
                              )
                            }
                            className={`cursor-pointer ${
                              img.is_primary ? 'text-sky-800 font-bold' : 'text-slate-500 hover:text-sky-700'
                            }`}
                          >
                            {img.is_primary ? 'تصویر اصلی' : 'انتخاب اصلی'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setImages((prev) => prev.filter((_, i) => i !== idx))}
                            className="text-rose-600 hover:text-rose-800 cursor-pointer"
                          >
                            حذف
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Technical Specifications */}
              <div className="border-t border-slate-200 pt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">مشخصات فنی محصول</h4>
                  <button
                    type="button"
                    onClick={() => setSpecifications((prev) => [...prev, {spec_key: '', spec_value: ''}])}
                    className="text-xs font-semibold text-sky-700 hover:text-sky-900 cursor-pointer"
                  >
                    + افزودن سطر مشخصات
                  </button>
                </div>

                <div className="space-y-2">
                  {specifications.map((sp, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                      <input
                        type="text"
                        value={sp.spec_key}
                        onChange={(e) =>
                          setSpecifications((prev) =>
                            prev.map((row, i) => (i === idx ? {...row, spec_key: e.target.value} : row))
                          )
                        }
                        placeholder="عنوان (مثلاً ارتفاع تشک)"
                        className="col-span-5 border border-slate-200 rounded-lg px-3 py-1.5 text-xs"
                      />
                      <input
                        type="text"
                        value={sp.spec_value}
                        onChange={(e) =>
                          setSpecifications((prev) =>
                            prev.map((row, i) => (i === idx ? {...row, spec_value: e.target.value} : row))
                          )
                        }
                        placeholder="مقدار (مثلاً ۳۰ سانتی‌متر)"
                        className="col-span-6 border border-slate-200 rounded-lg px-3 py-1.5 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setSpecifications((prev) => prev.filter((_, i) => i !== idx))}
                        className="col-span-1 text-rose-600 hover:text-rose-800 flex justify-center cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-sm font-semibold rounded-lg cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-6 py-2 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg cursor-pointer disabled:opacity-60"
                >
                  {saving ? 'در حال ذخیره...' : editingId ? 'به‌روزرسانی محصول' : 'ایجاد محصول'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
