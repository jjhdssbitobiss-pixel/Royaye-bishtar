import {useRef, useState, type ChangeEvent} from 'react';
import {Upload} from 'lucide-react';
import {apiRequest, ApiError} from '../../api/client';

interface AdminImagePickerProps {
  onUploaded: (url: string) => void;
  buttonLabel?: string;
}

export function AdminImagePicker({
  onUploaded,
  buttonLabel = 'بارگذاری تصویر از دستگاه',
}: AdminImagePickerProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setError('فقط فرمت‌های JPG، PNG و WebP مجاز هستند.');
      return;
    }
    if (file.size > 3.5 * 1024 * 1024) {
      setError('حجم فایل باید کمتر از ۳.۵ مگابایت باشد.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      setUploading(true);
      try {
        const res = await apiRequest<{url: string}>('/api/admin/upload', {
          method: 'POST',
          body: JSON.stringify({filename: file.name, dataUrl}),
        });
        onUploaded(res.url);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'خطا در آپلود تصویر.');
      } finally {
        setUploading(false);
        if (inputRef.current) inputRef.current.value = '';
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-1.5">
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleFileChange}
        className="hidden"
      />
      <button
        type="button"
        disabled={uploading}
        onClick={() => inputRef.current?.click()}
        className="inline-flex items-center gap-2 px-3.5 py-2 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-60"
      >
        <Upload className="w-3.5 h-3.5" />
        <span>{uploading ? 'در حال بارگذاری...' : buttonLabel}</span>
      </button>
      {error && <p className="text-xs text-rose-700">{error}</p>}
    </div>
  );
}
