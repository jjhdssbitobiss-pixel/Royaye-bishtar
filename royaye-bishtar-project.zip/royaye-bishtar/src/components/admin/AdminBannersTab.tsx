import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {Edit3, Trash2} from 'lucide-react';
import {apiRequest, ApiError} from '../../api/client';
import type {Banner} from '../../types';
import {SafeImage} from '../SafeImage';
import {AdminImagePicker} from './AdminImagePicker';

export function AdminBannersTab() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('/catalog');
  const [buttonText, setButtonText] = useState('مشاهده محصولات');
  const [position, setPosition] = useState<'hero' | 'promo'>('promo');
  const [sortOrder, setSortOrder] = useState('1');
  const [isActive, setIsActive] = useState(true);
  const [error, setError] = useState('');

  const loadBanners = useCallback(async () => {
    try {
      const res = await apiRequest<{banners: Banner[]}>('/api/admin/banners');
      setBanners(res.banners);
    } catch {
      setBanners([]);
    }
  }, []);

  useEffect(() => {
    loadBanners();
  }, [loadBanners]);

  const resetForm = () => {
    setEditingId(null);
    setTitle('');
    setSubtitle('');
    setImageUrl('');
    setLinkUrl('/catalog');
    setButtonText('مشاهده محصولات');
    setPosition('promo');
    setSortOrder('1');
    setIsActive(true);
    setError('');
  };

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    const payload = {
      title,
      subtitle,
      image_url: imageUrl,
      link_url: linkUrl,
      button_text: buttonText,
      position,
      sort_order: Number(sortOrder),
      is_active: isActive,
    };

    try {
      if (editingId) {
        await apiRequest(`/api/admin/banners/${editingId}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiRequest('/api/admin/banners', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }
      resetForm();
      await loadBanners();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'خطا در ذخیره بنر.');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await apiRequest(`/api/admin/banners/${id}`, {method: 'DELETE'});
      await loadBanners();
    } catch {
      // ignore
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <form
        onSubmit={handleSave}
        className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-4"
      >
        <h3 className="text-base font-bold text-slate-900">
          {editingId ? 'ویرایش بنر تبلیغاتی' : 'افزودن بنر جدید'}
        </h3>

        {error && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs p-3 rounded-lg">
            {error}
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">عنوان بنر</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">توضیح یا زیرعنوان</label>
          <textarea
            rows={2}
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-semibold text-slate-700">تصویر بنر</label>
          <AdminImagePicker onUploaded={(url) => setImageUrl(url)} buttonLabel="آپلود تصویر بنر" />
          <input
            type="text"
            required
            dir="ltr"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="/uploads/... یا /src/assets/..."
            className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-left"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">لینک دکمه</label>
            <input
              type="text"
              dir="ltr"
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-left"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">متن دکمه</label>
            <input
              type="text"
              value={buttonText}
              onChange={(e) => setButtonText(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-xs"
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 items-center">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">جایگاه</label>
            <select
              value={position}
              onChange={(e) => setPosition(e.target.value === 'hero' ? 'hero' : 'promo')}
              className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs"
            >
              <option value="hero">بنر اصلی بالا</option>
              <option value="promo">بنر تبلیغاتی میانی</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">ترتیب</label>
            <input
              type="number"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs tabular-nums"
            />
          </div>
          <label className="flex items-center gap-1.5 text-xs text-slate-700 pt-4 cursor-pointer">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="w-4 h-4 accent-sky-700"
            />
            <span>فعال</span>
          </label>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <button
            type="submit"
            className="flex-1 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg cursor-pointer"
          >
            {editingId ? 'به‌روزرسانی بنر' : 'ثبت بنر'}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2.5 bg-slate-100 text-slate-700 text-sm font-semibold rounded-lg cursor-pointer"
            >
              انصراف
            </button>
          )}
        </div>
      </form>

      <div className="lg:col-span-7 space-y-4">
        {banners.map((b) => (
          <div key={b.id} className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row gap-4">
            <div className="sm:w-44 h-28 rounded-lg overflow-hidden bg-sky-50 border border-slate-100 shrink-0">
              <SafeImage src={b.image_url} alt={b.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 flex flex-col justify-between gap-2">
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-900">{b.title}</h4>
                  <span className="text-xs font-semibold text-slate-500">
                    {b.position === 'hero' ? 'بالای صفحه' : 'تبلیغاتی'} · {b.is_active ? 'فعال' : 'غیرفعال'}
                  </span>
                </div>
                {b.subtitle && <p className="text-xs text-slate-600 mt-1 line-clamp-2">{b.subtitle}</p>}
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(b.id);
                    setTitle(b.title);
                    setSubtitle(b.subtitle || '');
                    setImageUrl(b.image_url);
                    setLinkUrl(b.link_url || '');
                    setButtonText(b.button_text || '');
                    setPosition(b.position);
                    setSortOrder(String(b.sort_order));
                    setIsActive(b.is_active === 1);
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-sky-50 text-sky-800 text-xs font-semibold rounded-lg cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  ویرایش
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(b.id)}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-rose-50 text-rose-700 text-xs font-semibold rounded-lg cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  حذف
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
