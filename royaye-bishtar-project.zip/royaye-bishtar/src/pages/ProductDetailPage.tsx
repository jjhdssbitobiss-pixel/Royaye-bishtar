import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {Check, Edit3, Eye, Star, ThumbsUp, Trash2} from 'lucide-react';
import {apiRequest, ApiError} from '../api/client';
import {ProductCard} from '../components/ProductCard';
import {SafeImage} from '../components/SafeImage';
import {StarRating} from '../components/StarRating';
import {useAuth} from '../context/AuthContext';
import type {
  ProductDetail,
  ProductImage,
  ProductListItem,
  ProductSpecification,
  RatingSummary,
  ReviewItem,
} from '../types';
import {
  formatDateFa,
  formatNumberFa,
  formatPriceToman,
  getReviewStatusLabel,
  getStockLabel,
  toPersianDigits,
} from '../utils/format';

interface ProductResponse {
  product: ProductDetail;
  images: ProductImage[];
  specifications: ProductSpecification[];
  ratingSummary: RatingSummary;
  reviews: ReviewItem[];
  myRating: number | null;
  myReviews: ReviewItem[];
  related: ProductListItem[];
}

interface ProductDetailPageProps {
  productId: string;
  onNavigate: (path: string) => void;
}

export function ProductDetailPage({productId, onNavigate}: ProductDetailPageProps) {
  const {isAuthenticated} = useAuth();
  const [data, setData] = useState<ProductResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [reviewSort, setReviewSort] = useState<'newest' | 'helpful'>('newest');

  // Review & Rating state
  const [myScoreInput, setMyScoreInput] = useState<number>(0);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{type: 'ok' | 'err'; text: string} | null>(null);

  // Edit own review state
  const [editingReviewId, setEditingReviewId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editComment, setEditComment] = useState('');

  const loadProduct = useCallback(
    async (track: boolean, sortMode: 'newest' | 'helpful') => {
      try {
        const res = await apiRequest<ProductResponse>(
          `/api/products/${encodeURIComponent(productId)}?reviewSort=${sortMode}${track ? '&track=1' : ''}`
        );
        setData(res);
        setMyScoreInput(res.myRating || 0);
        setError('');
      } catch (err) {
        setError(err instanceof Error ? err.message : 'محصول یافت نشد.');
      } finally {
        setLoading(false);
      }
    },
    [productId]
  );

  useEffect(() => {
    setLoading(true);
    setSelectedImageIdx(0);
    setFeedbackMsg(null);
    loadProduct(true, 'newest');
  }, [productId, loadProduct]);

  const handleSortChange = (mode: 'newest' | 'helpful') => {
    setReviewSort(mode);
    loadProduct(false, mode);
  };

  const handleRateProduct = async (score: number) => {
    if (!data || !isAuthenticated) return;
    setFeedbackMsg(null);
    try {
      const res = await apiRequest<{myRating: number; ratingSummary: RatingSummary}>(
        `/api/products/${data.product.id}/rate`,
        {
          method: 'POST',
          body: JSON.stringify({score}),
        }
      );
      setMyScoreInput(res.myRating);
      setData((prev) => (prev ? {...prev, myRating: res.myRating, ratingSummary: res.ratingSummary} : prev));
      setFeedbackMsg({type: 'ok', text: `امتیاز ${toPersianDigits(score)} ستاره شما ثبت شد.`});
    } catch (err) {
      setFeedbackMsg({
        type: 'err',
        text: err instanceof ApiError ? err.message : 'خطا در ثبت امتیاز.',
      });
    }
  };

  const handleSubmitReview = async (e: FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setFeedbackMsg(null);
    setSubmittingReview(true);
    try {
      const res = await apiRequest<{message: string}>(`/api/products/${data.product.id}/reviews`, {
        method: 'POST',
        body: JSON.stringify({
          title: reviewTitle.trim(),
          comment: reviewComment.trim(),
          score: myScoreInput > 0 ? myScoreInput : undefined,
        }),
      });
      setReviewTitle('');
      setReviewComment('');
      setFeedbackMsg({type: 'ok', text: res.message});
      await loadProduct(false, reviewSort);
    } catch (err) {
      setFeedbackMsg({
        type: 'err',
        text: err instanceof ApiError ? err.message : 'خطا در ثبت نظر.',
      });
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleSaveEdit = async (reviewId: number) => {
    setFeedbackMsg(null);
    try {
      const res = await apiRequest<{message: string}>(`/api/reviews/${reviewId}`, {
        method: 'PUT',
        body: JSON.stringify({title: editTitle.trim(), comment: editComment.trim()}),
      });
      setEditingReviewId(null);
      setFeedbackMsg({type: 'ok', text: res.message});
      await loadProduct(false, reviewSort);
    } catch (err) {
      setFeedbackMsg({
        type: 'err',
        text: err instanceof ApiError ? err.message : 'خطا در ویرایش نظر.',
      });
    }
  };

  const handleDeleteReview = async (reviewId: number) => {
    setFeedbackMsg(null);
    try {
      await apiRequest(`/api/reviews/${reviewId}`, {method: 'DELETE'});
      setFeedbackMsg({type: 'ok', text: 'نظر شما با موفقیت حذف شد.'});
      await loadProduct(false, reviewSort);
    } catch (err) {
      setFeedbackMsg({
        type: 'err',
        text: err instanceof ApiError ? err.message : 'خطا در حذف نظر.',
      });
    }
  };

  const handleToggleHelpful = async (reviewId: number) => {
    if (!isAuthenticated) {
      onNavigate('/auth');
      return;
    }
    try {
      const res = await apiRequest<{helpful_count: number; user_voted_helpful: number}>(
        `/api/reviews/${reviewId}/helpful`,
        {method: 'POST'}
      );
      setData((prev) =>
        prev
          ? {
              ...prev,
              reviews: prev.reviews.map((r) =>
                r.id === reviewId
                  ? {...r, helpful_count: res.helpful_count, user_voted_helpful: res.user_voted_helpful}
                  : r
              ),
            }
          : prev
      );
    } catch {
      // ignore transient error
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-6 h-96 rounded-2xl bg-slate-100 animate-pulse" />
          <div className="lg:col-span-6 h-96 rounded-2xl bg-slate-100 animate-pulse" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-4">
        <p className="text-lg font-bold text-slate-800">{error || 'محصول مورد نظر یافت نشد.'}</p>
        <button
          type="button"
          onClick={() => onNavigate('/catalog')}
          className="px-5 py-2.5 bg-sky-700 text-white text-sm font-semibold rounded-lg cursor-pointer"
        >
          بازگشت به کاتالوگ
        </button>
      </div>
    );
  }

  const {product, images, specifications, ratingSummary, reviews, myReviews, related} = data;
  const activeImage = images[selectedImageIdx] || images[0];
  const stock = getStockLabel(product.stock_status);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-14">
      {/* Breadcrumb */}
      <nav className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
        <button type="button" onClick={() => onNavigate('/')} className="hover:text-sky-700 cursor-pointer">
          صفحه اصلی
        </button>
        <span aria-hidden="true">/</span>
        <button
          type="button"
          onClick={() => onNavigate(`/catalog?categoryId=${product.category_id}`)}
          className="hover:text-sky-700 cursor-pointer"
        >
          {product.category_name}
        </button>
        <span aria-hidden="true">/</span>
        <span className="text-slate-900 font-medium">{product.name}</span>
      </nav>

      {/* Main Product Showcase & Info Module */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
        {/* Image Gallery */}
        <div className="lg:col-span-6 space-y-3 lg:sticky lg:top-24">
          <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden border border-slate-200 bg-sky-50/40">
            <SafeImage
              src={activeImage?.image_url}
              alt={activeImage?.alt_text || product.name}
              fallbackTitle={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {images.length > 1 && (
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
              {images.map((img, idx) => (
                <button
                  key={img.id}
                  type="button"
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`aspect-[4/3] rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                    idx === selectedImageIdx
                      ? 'border-sky-600 ring-2 ring-sky-100'
                      : 'border-slate-200 opacity-80 hover:opacity-100'
                  }`}
                >
                  <SafeImage
                    src={img.image_url}
                    alt={img.alt_text || product.name}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="lg:col-span-6 space-y-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>{product.parent_category_name ? `${product.parent_category_name} / ${product.category_name}` : product.category_name}</span>
              {product.brand_name && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>برند {product.brand_name}</span>
                </>
              )}
              {product.sku && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">کد کالا: {product.sku}</span>
                </>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
              {product.name}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <StarRating value={ratingSummary.avg_rating} size="sm" />
                <span className="font-bold text-slate-900 tabular-nums">
                  {ratingSummary.total_ratings > 0 ? toPersianDigits(ratingSummary.avg_rating) : '۰'}
                </span>
                <span className="text-slate-500 tabular-nums">
                  ({formatNumberFa(ratingSummary.total_ratings)} امتیاز · {formatNumberFa(reviews.length)} نظر)
                </span>
              </div>

              <span className="text-slate-300">|</span>
              <span className="inline-flex items-center gap-1 text-xs text-slate-500 tabular-nums">
                <Eye className="w-4 h-4 text-slate-400" />
                {formatNumberFa(product.view_count)} بازدید
              </span>
            </div>
          </div>

          <div className="bg-sky-50/70 border border-sky-100 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs text-slate-500 mb-1">قیمت محصول</div>
              <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
                {formatPriceToman(product.price)}
              </div>
            </div>
            <div className="text-sm font-semibold">
              <span
                className={
                  stock.tone === 'emerald'
                    ? 'text-emerald-700'
                    : stock.tone === 'amber'
                      ? 'text-amber-700'
                      : 'text-rose-700'
                }
              >
                {stock.text}
              </span>
              {product.stock_quantity > 0 && (
                <span className="text-xs text-slate-500 block mt-0.5 tabular-nums">
                  تعداد موجود: {formatNumberFa(product.stock_quantity)} عدد
                </span>
              )}
            </div>
          </div>

          {product.short_description && (
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed">{product.short_description}</p>
          )}

          <div className="space-y-4 border-t border-slate-200 pt-5 text-sm">
            {product.dimensions && (
              <div>
                <h2 className="font-bold text-slate-900 mb-1">ابعاد و سایزبندی</h2>
                <p className="text-slate-600 leading-relaxed">{product.dimensions}</p>
              </div>
            )}
            {product.material && (
              <div>
                <h2 className="font-bold text-slate-900 mb-1">جنس و مواد اولیه</h2>
                <p className="text-slate-600 leading-relaxed">{product.material}</p>
              </div>
            )}
            {product.features && (
              <div>
                <h2 className="font-bold text-slate-900 mb-1.5">ویژگی‌ها و مزایا</h2>
                <ul className="space-y-1.5 text-slate-600">
                  {product.features
                    .split(/،|,|\n/)
                    .map((f) => f.trim())
                    .filter(Boolean)
                    .map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-sky-700 mt-0.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Full Description & Technical Specifications */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 border-t border-slate-200 pt-10">
        <div className="lg:col-span-6 space-y-3">
          <h2 className="text-xl font-bold text-slate-900">توضیحات کامل محصول</h2>
          <p className="text-sm sm:text-base text-slate-700 leading-loose whitespace-pre-line">
            {product.description}
          </p>
        </div>

        <div className="lg:col-span-6 space-y-3">
          <h2 className="text-xl font-bold text-slate-900">مشخصات فنی</h2>
          {specifications.length === 0 ? (
            <p className="text-sm text-slate-500">مشخصات فنی تکمیلی برای این محصول ثبت نشده است.</p>
          ) : (
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {specifications.map((spec, idx) => (
                    <tr
                      key={spec.id}
                      className={idx % 2 === 0 ? 'bg-slate-50/70' : 'bg-white'}
                    >
                      <th className="text-right font-semibold text-slate-700 px-4 py-3 w-2/5 border-b border-slate-100">
                        {spec.spec_key}
                      </th>
                      <td className="text-slate-800 px-4 py-3 border-b border-slate-100">
                        {spec.spec_value}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* Ratings & Reviews System */}
      <section className="border-t border-slate-200 pt-10 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">امتیازها و نظرات کاربران</h2>
            <p className="text-sm text-slate-500 mt-1">
              تجربه مشتریان درباره کیفیت خواب، راحتی و دوام این محصول
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
            <button
              type="button"
              onClick={() => handleSortChange('newest')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                reviewSort === 'newest'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              جدیدترین
            </button>
            <button
              type="button"
              onClick={() => handleSortChange('helpful')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                reviewSort === 'helpful'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              مفیدترین
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Rating Summary & Submit Form */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-sky-50/50 border border-sky-100 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-3xl font-extrabold text-slate-900 tabular-nums">
                    {ratingSummary.total_ratings > 0 ? toPersianDigits(ratingSummary.avg_rating) : '۰'}
                    <span className="text-sm font-normal text-slate-500 mr-1">از ۵</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1 tabular-nums">
                    بر اساس {formatNumberFa(ratingSummary.total_ratings)} امتیاز ثبت‌شده
                  </div>
                </div>
                <StarRating value={ratingSummary.avg_rating} size="md" />
              </div>

              <div className="space-y-1.5 pt-2 border-t border-sky-100">
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = Number(ratingSummary[`star_${star}` as keyof RatingSummary] || 0);
                  const pct =
                    ratingSummary.total_ratings > 0
                      ? Math.round((count / ratingSummary.total_ratings) * 100)
                      : 0;
                  return (
                    <div key={star} className="flex items-center gap-2 text-xs text-slate-600 tabular-nums">
                      <span className="w-10 shrink-0">{toPersianDigits(star)} ستاره</span>
                      <div className="flex-1 h-2 bg-white rounded-full overflow-hidden border border-sky-100">
                        <div className="h-full bg-amber-400 rounded-full" style={{width: `${pct}%`}} />
                      </div>
                      <span className="w-7 text-left text-slate-500">{formatNumberFa(count)}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Interactive Rating & Review Box */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <h3 className="text-base font-bold text-slate-900">ثبت امتیاز و دیدگاه شما</h3>

              {feedbackMsg && (
                <div
                  className={`text-xs p-3 rounded-lg border ${
                    feedbackMsg.type === 'ok'
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border-rose-200 text-rose-800'
                  }`}
                >
                  {feedbackMsg.text}
                </div>
              )}

              {!isAuthenticated ? (
                <div className="space-y-3 text-sm text-slate-600">
                  <p>برای امتیازدهی (۱ تا ۵ ستاره) و ثبت نظر، ابتدا وارد حساب کاربری خود شوید.</p>
                  <button
                    type="button"
                    onClick={() => onNavigate('/auth')}
                    className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    ورود یا ثبت‌نام مشتری
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <div className="text-xs font-semibold text-slate-700 mb-2">
                      امتیاز شما به این محصول (قابل ویرایش):
                    </div>
                    <div className="flex items-center gap-3">
                      <StarRating
                        value={myScoreInput}
                        interactive
                        size="lg"
                        onChange={handleRateProduct}
                      />
                      {myScoreInput > 0 && (
                        <span className="text-xs font-semibold text-sky-800 tabular-nums">
                          {toPersianDigits(myScoreInput)} از ۵
                        </span>
                      )}
                    </div>
                  </div>

                  <form onSubmit={handleSubmitReview} className="space-y-3 pt-3 border-t border-slate-100">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        عنوان نظر (اختیاری)
                      </label>
                      <input
                        type="text"
                        value={reviewTitle}
                        onChange={(e) => setReviewTitle(e.target.value)}
                        maxLength={120}
                        placeholder="خلاصه تجربه شما..."
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        متن نظر
                      </label>
                      <textarea
                        rows={4}
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        required
                        minLength={8}
                        maxLength={1500}
                        placeholder="نقاط قوت، راحتی، کیفیت دوخت یا الیاف را بنویسید..."
                        className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <p className="text-xs text-slate-500">
                      نظرات جدید پس از بررسی و تایید مدیر در صفحه محصول نمایش داده می‌شوند.
                    </p>
                    <button
                      type="submit"
                      disabled={submittingReview}
                      className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
                    >
                      {submittingReview ? 'در حال ثبت...' : 'ثبت نظر'}
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>

          {/* Reviews Feed */}
          <div className="lg:col-span-8 space-y-5">
            {/* User's own pending/rejected/editable reviews on this product */}
            {myReviews.length > 0 && (
              <div className="bg-sky-50/40 border border-sky-200 rounded-xl p-4 space-y-3">
                <h3 className="text-sm font-bold text-sky-900">نظرات ثبت‌شده شما برای این محصول</h3>
                {myReviews.map((mr) => {
                  const st = getReviewStatusLabel(mr.status);
                  const isEditing = editingReviewId === mr.id;
                  return (
                    <div key={mr.id} className="bg-white border border-slate-200 rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span
                          className={`font-semibold ${
                            st.tone === 'emerald'
                              ? 'text-emerald-700'
                              : st.tone === 'amber'
                                ? 'text-amber-700'
                                : 'text-rose-700'
                          }`}
                        >
                          وضعیت: {st.text}
                        </span>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingReviewId(isEditing ? null : mr.id);
                              setEditTitle(mr.title || '');
                              setEditComment(mr.comment);
                            }}
                            className="inline-flex items-center gap-1 text-sky-700 hover:text-sky-900 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            ویرایش
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteReview(mr.id)}
                            className="inline-flex items-center gap-1 text-rose-700 hover:text-rose-900 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            حذف
                          </button>
                        </div>
                      </div>

                      {isEditing ? (
                        <div className="space-y-2 pt-2">
                          <input
                            type="text"
                            value={editTitle}
                            onChange={(e) => setEditTitle(e.target.value)}
                            placeholder="عنوان نظر"
                            className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm"
                          />
                          <textarea
                            rows={3}
                            value={editComment}
                            onChange={(e) => setEditComment(e.target.value)}
                            className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm"
                          />
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleSaveEdit(mr.id)}
                              className="px-4 py-1.5 bg-sky-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                            >
                              ذخیره تغییرات
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingReviewId(null)}
                              className="px-4 py-1.5 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer"
                            >
                              انصراف
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {mr.title && <div className="text-sm font-bold text-slate-900">{mr.title}</div>}
                          <p className="text-sm text-slate-700 leading-relaxed">{mr.comment}</p>
                          {mr.admin_note && (
                            <p className="text-xs text-slate-500 pt-1">یادداشت مدیر: {mr.admin_note}</p>
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {reviews.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 text-center">
                <p className="text-sm font-semibold text-slate-700">
                  هنوز نظر تاییدشده‌ای برای این محصول ثبت نشده است.
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  اولین نفری باشید که تجربه خود را با دیگر خریداران به اشتراک می‌گذارد.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {reviews.map((rv) => (
                  <article key={rv.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="text-sm font-bold text-slate-900">{rv.user_name}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatDateFa(rv.created_at)}</span>
                        {rv.user_rating && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="inline-flex items-center gap-1 text-slate-800 font-semibold tabular-nums">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              {toPersianDigits(rv.user_rating)}
                            </span>
                          </>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleToggleHelpful(rv.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                          rv.user_voted_helpful
                            ? 'bg-sky-50 border-sky-300 text-sky-800'
                            : 'bg-white border-slate-200 text-slate-600 hover:border-sky-200'
                        }`}
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>مفید بود</span>
                        <span className="tabular-nums">({formatNumberFa(rv.helpful_count)})</span>
                      </button>
                    </div>

                    {rv.title && <h4 className="text-base font-bold text-slate-900">{rv.title}</h4>}
                    <p className="text-sm text-slate-700 leading-relaxed">{rv.comment}</p>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="border-t border-slate-200 pt-10 space-y-6">
          <h2 className="text-xl font-bold text-slate-900">محصولات مرتبط در همین دسته‌بندی</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} onNavigate={onNavigate} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
