import {useEffect, useState, type FormEvent} from 'react';
import {Search, ArrowLeft} from 'lucide-react';
import {apiRequest} from '../api/client';
import {ProductCard} from '../components/ProductCard';
import {SafeImage} from '../components/SafeImage';
import type {Banner, Category, ProductListItem} from '../types';
import {formatNumberFa} from '../utils/format';

interface HomeData {
  banners: Banner[];
  categories: Category[];
  newest: ProductListItem[];
  featured: ProductListItem[];
  mostViewed: ProductListItem[];
  highestRated: ProductListItem[];
}

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export function HomePage({onNavigate}: HomePageProps) {
  const [data, setData] = useState<HomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    let active = true;
    apiRequest<HomeData>('/api/home')
      .then((res) => {
        if (active) setData(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'خطا در بارگذاری اطلاعات');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = searchQuery.trim();
    onNavigate(trimmed ? `/catalog?q=${encodeURIComponent(trimmed)}` : '/catalog');
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-12">
        <div className="h-[380px] rounded-2xl bg-sky-50 animate-pulse" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Array.from({length: 8}).map((_, i) => (
            <div key={i} className="h-24 rounded-xl bg-slate-100 animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({length: 3}).map((_, i) => (
            <div key={i} className="h-80 rounded-xl bg-slate-100 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <p className="text-slate-700 mb-4">{error || 'خطا در دریافت اطلاعات فروشگاه.'}</p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="px-5 py-2.5 bg-sky-700 text-white text-sm font-medium rounded-lg cursor-pointer"
        >
          تلاش مجدد
        </button>
      </div>
    );
  }

  const heroBanner = data.banners.find((b) => b.position === 'hero') || data.banners[0];
  const promoBanners = data.banners.filter((b) => b.position === 'promo');
  const rootCategories = data.categories.filter((c) => c.parent_id === null);

  return (
    <div className="space-y-16 pb-8">
      {/* Hero Section with Search Bar */}
      <section className="bg-gradient-to-b from-sky-50/80 via-sky-50/30 to-white border-b border-sky-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center gap-6">
              <div className="space-y-4">
                <p className="text-xs sm:text-sm font-semibold text-sky-700">
                  کاتالوگ تخصصی کالای خواب رویای بیشتر
                </p>
                <h1 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-extrabold text-slate-900 leading-tight text-balance">
                  {heroBanner ? heroBanner.title : 'خوابی عمیق با کالای خواب رویای بیشتر'}
                </h1>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-xl">
                  {heroBanner?.subtitle ||
                    'مشاهده مشخصات فنی دقیق تشک‌های طبی، بالش‌های هوشمند، روتختی کتان و نظرات واقعی مشتریان پیش از انتخاب.'}
                </p>
              </div>

              {/* Search Bar */}
              <form onSubmit={handleSearch} className="w-full max-w-xl">
                <div className="flex items-center bg-white border border-slate-200 focus-within:border-sky-600 focus-within:ring-2 focus-within:ring-sky-100 rounded-xl p-1.5 shadow-xs transition-all">
                  <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو در تشک، بالش، روتختی، برند یا جنس..."
                    className="w-full bg-transparent px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    جستجو
                  </button>
                </div>
              </form>

              <div className="flex flex-wrap items-center gap-4 pt-1">
                <button
                  type="button"
                  onClick={() => onNavigate(heroBanner?.link_url || '/catalog')}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {heroBanner?.button_text || 'مشاهده همه محصولات'}
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('/categories')}
                  className="px-5 py-2.5 bg-white hover:bg-sky-50 text-sky-800 border border-sky-200 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  مرور دسته‌بندی‌ها
                </button>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="h-64 sm:h-80 lg:h-full min-h-[320px] rounded-2xl overflow-hidden border border-sky-100 bg-sky-50">
                <SafeImage
                  src={heroBanner?.image_url}
                  alt={heroBanner?.title || 'کالای خواب رویای بیشتر'}
                  fallbackTitle="فروشگاه کالای خواب رویای بیشتر"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Category Access */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">دسترسی سریع به دسته‌بندی‌ها</h2>
            <p className="text-sm text-slate-500 mt-1">انتخاب محصول متناسب با نیاز اتاق خواب شما</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('/categories')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-sky-700 hover:text-sky-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            همه دسته‌بندی‌ها
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {rootCategories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => onNavigate(`/catalog?categoryId=${cat.id}`)}
              className="group bg-white border border-slate-200 hover:border-sky-300 hover:bg-sky-50/40 rounded-xl p-2.5 sm:p-4 flex items-center gap-2.5 sm:gap-3.5 text-right transition-all cursor-pointer"
            >
              <div className="w-11 h-11 sm:w-14 sm:h-14 rounded-lg overflow-hidden bg-sky-50 shrink-0 border border-slate-100">
                <SafeImage
                  src={cat.image_url}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-bold text-slate-900 group-hover:text-sky-800 truncate">
                  {cat.name}
                </div>
                <div className="text-xs text-slate-500 mt-0.5 tabular-nums">
                  {formatNumberFa(cat.product_count ?? 0)} محصول
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      {data.featured.length > 0 && (
        <ProductShelf
          title="محصولات منتخب و ویژه"
          subtitle="برترین انتخاب‌های پیشنهادی رویای بیشتر با بالاترین کیفیت ساخت"
          products={data.featured.slice(0, 3)}
          onViewAll={() => onNavigate('/catalog?featured=1')}
          onNavigate={onNavigate}
        />
      )}

      {/* Admin Promotional Banners */}
      {promoBanners.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
          {promoBanners.map((banner) => (
            <div
              key={banner.id}
              className="bg-sky-900 text-white rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch"
            >
              <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center gap-4">
                <h2 className="text-xl sm:text-2xl font-bold leading-snug text-balance">
                  {banner.title}
                </h2>
                {banner.subtitle && (
                  <p className="text-sm sm:text-base text-sky-100 leading-relaxed max-w-xl">
                    {banner.subtitle}
                  </p>
                )}
                {banner.link_url && (
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => onNavigate(banner.link_url || '/catalog')}
                      className="px-5 py-2.5 bg-white text-sky-900 hover:bg-sky-50 text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      {banner.button_text || 'مشاهده محصولات'}
                    </button>
                  </div>
                )}
              </div>
              <div className="lg:col-span-5 h-56 lg:h-auto min-h-[220px]">
                <SafeImage
                  src={banner.image_url}
                  alt={banner.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Newest Products */}
      {data.newest.length > 0 && (
        <ProductShelf
          title="محصولات جدید"
          subtitle="تازه‌ترین کالاهای خواب اضافه‌شده به کاتالوگ فروشگاه"
          products={data.newest.slice(0, 3)}
          onViewAll={() => onNavigate('/catalog?sort=newest')}
          onNavigate={onNavigate}
        />
      )}

      {/* Most Viewed Products */}
      {data.mostViewed.length > 0 && (
        <ProductShelf
          title="محصولات پربازدید"
          subtitle="محصولاتی که بیشترین توجه و بررسی را از سوی بازدیدکنندگان داشته‌اند"
          products={data.mostViewed.slice(0, 3)}
          onViewAll={() => onNavigate('/catalog?sort=popular')}
          onNavigate={onNavigate}
        />
      )}

      {/* Highest Rated Products */}
      {data.highestRated.length > 0 && (
        <ProductShelf
          title="محصولات دارای بالاترین امتیاز"
          subtitle="انتخاب‌های برتر بر اساس امتیاز و تجربه ثبت‌شده مشتریان"
          products={data.highestRated.slice(0, 3)}
          onViewAll={() => onNavigate('/catalog?sort=rating')}
          onNavigate={onNavigate}
        />
      )}
    </div>
  );
}

function ProductShelf({
  title,
  subtitle,
  products,
  onViewAll,
  onNavigate,
}: {
  title: string;
  subtitle: string;
  products: ProductListItem[];
  onViewAll: () => void;
  onNavigate: (path: string) => void;
}) {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">{title}</h2>
          <p className="text-sm text-slate-500 mt-1">{subtitle}</p>
        </div>
        <button
          type="button"
          onClick={onViewAll}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-sky-700 hover:text-sky-800 whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
        >
          مشاهده همه
          <ArrowLeft className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
        ))}
      </div>
    </section>
  );
}
