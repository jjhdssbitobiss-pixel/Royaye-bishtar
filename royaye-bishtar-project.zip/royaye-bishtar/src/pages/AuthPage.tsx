import {useEffect, useState, type FormEvent} from 'react';
import {ShieldCheck} from 'lucide-react';
import {ApiError} from '../api/client';
import {useAuth} from '../context/AuthContext';

interface AuthPageProps {
  onNavigate: (path: string) => void;
}

export function AuthPage({onNavigate}: AuthPageProps) {
  const {isAuthenticated, isAdmin, needsAdminSetup, login, register, setupAdmin} = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'setup-admin'>('login');

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      onNavigate(isAdmin ? '/admin' : '/profile');
    }
  }, [isAuthenticated, isAdmin, onNavigate]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      if (mode === 'login') {
        const loggedUser = await login(email, password);
        onNavigate(loggedUser.role_name === 'admin' ? '/admin' : '/profile');
      } else if (mode === 'register') {
        await register({
          full_name: fullName,
          email,
          password,
          phone: phone || undefined,
          city: city || undefined,
        });
        onNavigate('/profile');
      } else {
        await setupAdmin({
          full_name: fullName,
          email,
          password,
        });
        onNavigate('/admin');
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'خطا در انجام عملیات.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-1.5">
          <h1 className="text-2xl font-extrabold text-slate-900">
            {mode === 'login'
              ? 'ورود به رویای بیشتر'
              : mode === 'register'
                ? 'ایجاد حساب کاربری مشتری'
                : 'راه‌اندازی حساب مدیر اولیه'}
          </h1>
          <p className="text-sm text-slate-500">
            {mode === 'login'
              ? 'برای ثبت نظر، امتیازدهی یا دسترسی به پنل مدیریت وارد شوید'
              : mode === 'register'
                ? 'با ساخت حساب کاربری می‌توانید تجربه‌های خود را ثبت و محصولات را امتیازدهی کنید'
                : 'برای امنیت فروشگاه، ایمیل و رمز عبور مدیر اصلی را یک‌بار تنظیم کنید'}
          </p>
        </div>

        {needsAdminSetup && (
          <div className="bg-sky-50 border border-sky-200 rounded-xl p-4 flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
              <div className="text-xs text-sky-900 leading-relaxed">
                هنوز حساب مدیر اصلی برای فروشگاه تنظیم نشده است. می‌توانید هم‌اکنون مدیر اولیه را تعریف کنید.
              </div>
            </div>
            {mode !== 'setup-admin' && (
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('setup-admin');
                }}
                className="px-3 py-1.5 bg-sky-700 text-white text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
              >
                ساخت مدیر
              </button>
            )}
          </div>
        )}

        {/* Mode Switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setError('');
              setMode('login');
            }}
            className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
              mode === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ورود
          </button>
          <button
            type="button"
            onClick={() => {
              setError('');
              setMode('register');
            }}
            className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
              mode === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ثبت‌نام مشتری
          </button>
          {needsAdminSetup && (
            <button
              type="button"
              onClick={() => {
                setError('');
                setMode('setup-admin');
              }}
              className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors cursor-pointer ${
                mode === 'setup-admin'
                  ? 'bg-white text-sky-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              مدیر اولیه
            </button>
          )}
        </div>

        {error && (
          <div className="bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm rounded-lg p-3">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {(mode === 'register' || mode === 'setup-admin') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                نام و نام خانوادگی
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="مثال: سارا محمدی"
                className="w-full border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-sky-600"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">ایمیل</label>
            <input
              type="email"
              required
              dir="ltr"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-left focus:outline-none focus:border-sky-600"
            />
          </div>

          {mode === 'register' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  شماره تماس (اختیاری)
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="09120000000"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-left focus:outline-none focus:border-sky-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  شهر (اختیاری)
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="مثال: تهران"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm focus:outline-none focus:border-sky-600"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">رمز عبور</label>
            <input
              type="password"
              required
              minLength={6}
              dir="ltr"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="حداقل ۶ کاراکتر"
              className="w-full border border-slate-200 rounded-lg px-3.5 py-2.5 text-sm text-left focus:outline-none focus:border-sky-600"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 bg-sky-700 hover:bg-sky-800 disabled:opacity-60 text-white text-sm font-bold rounded-lg transition-colors cursor-pointer"
          >
            {submitting
              ? 'لطفاً صبر کنید...'
              : mode === 'login'
                ? 'ورود به حساب'
                : mode === 'register'
                  ? 'تکمیل ثبت‌نام'
                  : 'ثبت حساب مدیر و ورود'}
          </button>
        </form>
      </div>
    </div>
  );
}
