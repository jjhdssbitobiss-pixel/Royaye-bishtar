import {useCallback, useEffect, useState, type FormEvent} from 'react';
import {Edit3, LogOut, Shield, Star, Trash2} from 'lucide-react';
import {apiRequest, ApiError} from '../api/client';
import {SafeImage} from '../components/SafeImage';
import {useAuth} from '../context/AuthContext';
import type {ReviewItem} from '../types';
import {formatDateFa, getReviewStatusLabel, toPersianDigits} from '../utils/format';

interface ProfilePageProps {
  onNavigate: (path: string) => void;
}

export function ProfilePage({onNavigate}: ProfilePageProps) {
  const {user, isAuthenticated, isAdmin, updateProfile, logout} = useAuth();

  const [fullName, setFullName] = useState(user?.full_name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [city, setCity] = useState(user?.city || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{type: 'ok' | 'err'; text: string} | null>(null);

  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editComment, setEditComment] = useState('');

  useEffect(() => {
    if (!isAuthenticated) {
      onNavigate('/auth');
      return;
    }
    if (user) {
      setFullName(user.full_name);
      setPhone(user.phone || '');
      setCity(user.city || '');
    }
  }, [isAuthenticated, user, onNavigate]);

  const loadMyReviews = useCallback(async () => {
    if (!isAuthenticated) return;
    setLoadingReviews(true);
    try {
      const res = await apiRequest<{reviews: ReviewItem[]}>('/api/my-reviews');
      setReviews(res.reviews);
    } catch {
      setReviews([]);
    } finally {
      setLoadingReviews(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    loadMyReviews();
  }, [loadMyReviews]);

  if (!user) return null;

  const handleSaveProfile = async (e: FormEvent) => {
    e.preventDefault();
    setProfileMsg(null);
    setSaving(true);
    try {
      await updateProfile({
        full_name: fullName.trim(),
        phone: phone.trim() || undefined,
        city: city.trim() || undefined,
        current_password: currentPassword || undefined,
        new_password: newPassword || undefined,
      });
      setCurrentPassword('');
      setNewPassword('');
      setProfileMsg({type: 'ok', text: 'اطلاعات پروفایل شما با موفقیت ذخیره شد.'});
    } catch (err) {
      setProfileMsg({
        type: 'err',
        text: err instanceof ApiError ? err.message : 'خطا در به‌روزرسانی پروفایل.',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateReview = async (reviewId: number) => {
    try {
      await apiRequest(`/api/reviews/${reviewId}`, {
        method: 'PUT',
        body: JSON.stringify({title: editTitle.trim(), comment: editComment.trim()}),
      });
      setEditingId(null);
      await loadMyReviews();
    } catch {
      // handled cleanly
    }
  };

  const handleDeleteReview = async (reviewId: number) => {
    try {
      await apiRequest(`/api/reviews/${reviewId}`, {method: 'DELETE'});
      await loadMyReviews();
    } catch {
      // ignore
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">حساب کاربری من</h1>
          <p className="text-sm text-slate-500 mt-1">
            {user.email} · {user.role_display_name}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isAdmin && (
            <button
              type="button"
              onClick={() => onNavigate('/admin')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg cursor-pointer"
            >
              <Shield className="w-4 h-4" />
              ورود به پنل مدیریت
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              logout();
              onNavigate('/');
            }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 hover:border-rose-300 text-rose-700 text-sm font-semibold rounded-lg cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            خروج از حساب
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Edit Profile Form */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">ویرایش اطلاعات پروفایل</h2>

          {profileMsg && (
            <div
              className={`text-xs p-3 rounded-lg border ${
                profileMsg.type === 'ok'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              {profileMsg.text}
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                نام و نام خانوادگی
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">شماره تماس</label>
                <input
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-left focus:outline-none focus:border-sky-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">شهر</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-600"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-3">
              <p className="text-xs font-semibold text-slate-500">تغییر رمز عبور (اختیاری)</p>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">رمز عبور فعلی</label>
                <input
                  type="password"
                  dir="ltr"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-left focus:outline-none focus:border-sky-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">رمز عبور جدید</label>
                <input
                  type="password"
                  dir="ltr"
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm text-left focus:outline-none focus:border-sky-600"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 bg-sky-700 hover:bg-sky-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              {saving ? 'در حال ذخیره...' : 'ذخیره اطلاعات'}
            </button>
          </form>
        </section>

        {/* User's Reviews History */}
        <section className="lg:col-span-7 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">نظرات و امتیازهای ثبت‌شده من</h2>

          {loadingReviews ? (
            <div className="h-40 rounded-xl bg-slate-100 animate-pulse" />
          ) : reviews.length === 0 ? (
            <div className="bg-sky-50/40 border border-sky-100 rounded-xl p-8 text-center space-y-3">
              <p className="text-sm font-semibold text-slate-700">شما هنوز نظری ثبت نکرده‌اید.</p>
              <button
                type="button"
                onClick={() => onNavigate('/catalog')}
                className="px-4 py-2 bg-sky-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
              >
                مشاهده محصولات کاتالوگ
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {reviews.map((rv) => {
                const st = getReviewStatusLabel(rv.status);
                const isEditing = editingId === rv.id;
                return (
                  <div key={rv.id} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
                    <div className="flex items-start justify-between gap-4">
                      <div
                        onClick={() => onNavigate(`/product/${rv.product_id}`)}
                        className="flex items-center gap-3 cursor-pointer group"
                      >
                        <div className="w-14 h-12 rounded-lg overflow-hidden bg-sky-50 border border-slate-100 shrink-0">
                          <SafeImage
                            src={rv.product_image}
                            alt={rv.product_name || 'محصول'}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 group-hover:text-sky-700">
                            {rv.product_name}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                            <span>{formatDateFa(rv.created_at)}</span>
                            <span aria-hidden="true">·</span>
                            <span
                              className={`font-semibold ${
                                st.tone === 'emerald'
                                  ? 'text-emerald-700'
                                  : st.tone === 'amber'
                                    ? 'text-amber-700'
                                    : 'text-rose-700'
                              }`}
                            >
                              {st.text}
                            </span>
                            {rv.my_rating && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="inline-flex items-center gap-0.5 text-slate-700 tabular-nums">
                                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                                  {toPersianDigits(rv.my_rating)}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingId(isEditing ? null : rv.id);
                            setEditTitle(rv.title || '');
                            setEditComment(rv.comment);
                          }}
                          className="p-1.5 text-sky-700 hover:bg-sky-50 rounded-lg cursor-pointer"
                          title="ویرایش نظر"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteReview(rv.id)}
                          className="p-1.5 text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer"
                          title="حذف نظر"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {isEditing ? (
                      <div className="space-y-2 pt-2 border-t border-slate-100">
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          placeholder="عنوان نظر"
                          className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm"
                        />
                        <textarea
                          rows={3}
                          value={editComment}
                          onChange={(e) => setEditComment(e.target.value)}
                          className="w-full border border-slate-200 rounded-lg px-3 py-1.5 text-sm"
                        />
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleUpdateReview(rv.id)}
                            className="px-4 py-1.5 bg-sky-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                          >
                            ذخیره و ارسال برای تایید
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="px-4 py-1.5 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer"
                          >
                            انصراف
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {rv.title && <div className="text-sm font-bold text-slate-900">{rv.title}</div>}
                        <p className="text-sm text-slate-600 leading-relaxed">{rv.comment}</p>
                        {rv.admin_note && (
                          <p className="text-xs text-slate-500 pt-1">یادداشت مدیر: {rv.admin_note}</p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
