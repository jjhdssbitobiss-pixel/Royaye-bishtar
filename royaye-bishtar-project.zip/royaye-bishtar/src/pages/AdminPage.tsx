import {useCallback, useEffect, useState} from 'react';
import {
  FolderTree,
  Image as ImageIcon,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Package,
  Users,
} from 'lucide-react';
import {apiRequest} from '../api/client';
import {AdminBannersTab} from '../components/admin/AdminBannersTab';
import {AdminCategoriesTab} from '../components/admin/AdminCategoriesTab';
import {AdminProductsTab} from '../components/admin/AdminProductsTab';
import {AdminReviewsTab} from '../components/admin/AdminReviewsTab';
import {AdminUsersTab} from '../components/admin/AdminUsersTab';
import {SafeImage} from '../components/SafeImage';
import {useAuth} from '../context/AuthContext';
import {formatNumberFa, toPersianDigits} from '../utils/format';

interface DashboardData {
  stats: {
    totalProducts: number;
    activeProducts: number;
    totalCategories: number;
    totalBrands: number;
    totalUsers: number;
    blockedUsers: number;
    totalReviews: number;
    pendingReviews: number;
    approvedReviews: number;
    totalRatings: number;
    totalViews: number;
  };
  mostViewed: {
    id: number;
    name: string;
    view_count: number;
    category_name: string;
    avg_rating: number;
    primary_image: string | null;
  }[];
  highestRated: {
    id: number;
    name: string;
    avg_rating: number;
    rating_count: number;
    category_name: string;
    primary_image: string | null;
  }[];
  recentPendingReviews: {
    id: number;
    title: string | null;
    comment: string;
    user_name: string;
    product_name: string;
  }[];
}

type AdminTab = 'dashboard' | 'products' | 'categories' | 'reviews' | 'users' | 'banners';

interface AdminPageProps {
  onNavigate: (path: string) => void;
}

export function AdminPage({onNavigate}: AdminPageProps) {
  const {user, isAuthenticated, isAdmin, logout} = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);

  const loadDashboard = useCallback(async () => {
    if (!isAuthenticated || !isAdmin) return;
    try {
      const res = await apiRequest<DashboardData>('/api/admin/dashboard');
      setDashboard(res);
    } catch {
      setDashboard(null);
    }
  }, [isAuthenticated, isAdmin]);

  useEffect(() => {
    if (!isAuthenticated) {
      onNavigate('/auth');
      return;
    }
    if (!isAdmin) {
      onNavigate('/');
      return;
    }
    loadDashboard();
  }, [isAuthenticated, isAdmin, onNavigate, loadDashboard]);

  if (!isAuthenticated || !isAdmin) return null;

  const navItems: {id: AdminTab; label: string; icon: typeof LayoutDashboard; badge?: number}[] = [
    {id: 'dashboard', label: 'داشبورد مدیریتی', icon: LayoutDashboard},
    {id: 'products', label: 'مدیریت محصولات', icon: Package},
    {id: 'categories', label: 'دسته‌بندی و برندها', icon: FolderTree},
    {
      id: 'reviews',
      label: 'نظرات و امتیازها',
      icon: MessageSquare,
      badge: dashboard?.stats.pendingReviews,
    },
    {id: 'users', label: 'مدیریت کاربران', icon: Users},
    {id: 'banners', label: 'مدیریت بنرها', icon: ImageIcon},
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Sidebar */}
        <aside className="lg:col-span-3 bg-white border border-slate-200 rounded-xl p-4 space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <div className="text-sm font-extrabold text-slate-900">{user?.full_name}</div>
            <div className="text-xs text-sky-700 mt-0.5">پنل مدیریت رویای بیشتر</div>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                    active
                      ? 'bg-sky-700 text-white font-semibold'
                      : 'text-slate-700 hover:bg-sky-50 hover:text-sky-800'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="whitespace-nowrap">{item.label}</span>
                  </span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`text-xs font-bold tabular-nums px-1.5 py-0.5 rounded ${
                        active ? 'bg-white text-sky-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {formatNumberFa(item.badge)}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          <div className="pt-3 border-t border-slate-100 space-y-1">
            <button
              type="button"
              onClick={() => onNavigate('/')}
              className="w-full text-right px-3 py-2 text-xs font-medium text-slate-600 hover:text-sky-800 cursor-pointer"
            >
              مشاهده نمای فروشگاه
            </button>
            <button
              type="button"
              onClick={() => {
                logout();
                onNavigate('/');
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 rounded-lg cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              خروج از پنل
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="lg:col-span-9 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl px-5 py-4 flex items-center justify-between">
            <h1 className="text-lg sm:text-xl font-extrabold text-slate-900">
              {navItems.find((i) => i.id === activeTab)?.label}
            </h1>
            <button
              type="button"
              onClick={() => onNavigate('/catalog')}
              className="text-xs font-semibold text-sky-700 hover:text-sky-900 cursor-pointer"
            >
              مشاهده کاتالوگ عمومی ←
            </button>
          </div>

          {activeTab === 'dashboard' && dashboard && (
            <div className="space-y-6">
              {/* KPI Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <StatCard label="کل محصولات" value={dashboard.stats.totalProducts} sub={`${formatNumberFa(dashboard.stats.activeProducts)} محصول فعال`} />
                <StatCard label="دسته‌بندی‌ها" value={dashboard.stats.totalCategories} sub={`${formatNumberFa(dashboard.stats.totalBrands)} برند ثبت‌شده`} />
                <StatCard label="کاربران مشتری" value={dashboard.stats.totalUsers} sub={`${formatNumberFa(dashboard.stats.blockedUsers)} کاربر مسدود`} />
                <StatCard label="کل نظرات" value={dashboard.stats.totalReviews} sub={`${formatNumberFa(dashboard.stats.approvedReviews)} نظر منتشرشده`} />
                <StatCard
                  label="نظرات در انتظار تایید"
                  value={dashboard.stats.pendingReviews}
                  highlight={dashboard.stats.pendingReviews > 0}
                  onClick={() => setActiveTab('reviews')}
                />
                <StatCard label="مجموع بازدید محصولات" value={dashboard.stats.totalViews} sub={`${formatNumberFa(dashboard.stats.totalRatings)} امتیاز ثبت‌شده`} />
              </div>

              {/* Most Viewed & Highest Rated */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 text-sm font-bold text-slate-900">
                    محصولات پربازدید
                  </div>
                  <div className="divide-y divide-slate-100">
                    {dashboard.mostViewed.map((p) => (
                      <div key={p.id} className="px-4 py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-lg overflow-hidden bg-sky-50 shrink-0">
                            <SafeImage src={p.primary_image} alt={p.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-slate-900 truncate">{p.name}</div>
                            <div className="text-xs text-slate-500">{p.category_name}</div>
                          </div>
                        </div>
                        <span className="text-xs font-bold text-sky-800 tabular-nums shrink-0">
                          {formatNumberFa(p.view_count)} بازدید
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 text-sm font-bold text-slate-900">
                    محصولات دارای بالاترین امتیاز
                  </div>
                  <div className="divide-y divide-slate-100">
                    {dashboard.highestRated.map((p) => (
                      <div key={p.id} className="px-4 py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-lg overflow-hidden bg-sky-50 shrink-0">
                            <SafeImage src={p.primary_image} alt={p.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-slate-900 truncate">{p.name}</div>
                            <div className="text-xs text-slate-500 tabular-nums">
                              {formatNumberFa(p.rating_count)} امتیاز
                            </div>
                          </div>
                        </div>
                        <span className="text-xs font-bold text-amber-700 tabular-nums shrink-0">
                          {toPersianDigits(p.avg_rating)} ★
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {dashboard.recentPendingReviews.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-3.5 border-b border-slate-200 bg-amber-50/60 flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900">نظرات جدید در انتظار بررسی</span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('reviews')}
                      className="text-xs font-semibold text-sky-700 cursor-pointer"
                    >
                      بررسی و تایید ←
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {dashboard.recentPendingReviews.map((rv) => (
                      <div key={rv.id} className="px-5 py-3 space-y-1">
                        <div className="text-xs font-bold text-slate-900">
                          {rv.user_name} · {rv.product_name}
                        </div>
                        <p className="text-xs text-slate-600 line-clamp-2">{rv.comment}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'products' && <AdminProductsTab onDataChanged={loadDashboard} />}
          {activeTab === 'categories' && <AdminCategoriesTab onDataChanged={loadDashboard} />}
          {activeTab === 'reviews' && <AdminReviewsTab onDataChanged={loadDashboard} />}
          {activeTab === 'users' && <AdminUsersTab onDataChanged={loadDashboard} />}
          {activeTab === 'banners' && <AdminBannersTab />}
        </main>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  sub,
  highlight = false,
  onClick,
}: {
  label: string;
  value: number;
  sub?: string;
  highlight?: boolean;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={`border rounded-xl p-4 space-y-1 ${
        highlight ? 'bg-amber-50/70 border-amber-200' : 'bg-white border-slate-200'
      } ${onClick ? 'cursor-pointer hover:border-sky-300' : ''}`}
    >
      <div className="text-xs text-slate-500 font-medium">{label}</div>
      <div className="text-2xl font-extrabold text-slate-900 tabular-nums">
        {formatNumberFa(value)}
      </div>
      {sub && <div className="text-xs text-slate-500 tabular-nums">{sub}</div>}
    </div>
  );
}
