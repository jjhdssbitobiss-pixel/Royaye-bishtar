import {useEffect, useState} from 'react';
import {ArrowLeft} from 'lucide-react';
import {apiRequest} from '../api/client';
import {SafeImage} from '../components/SafeImage';
import type {Category} from '../types';
import {formatNumberFa} from '../utils/format';

interface CategoriesPageProps {
  onNavigate: (path: string) => void;
}

export function CategoriesPage({onNavigate}: CategoriesPageProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiRequest<{categories: Category[]}>('/api/categories')
      .then((res) => setCategories(res.categories))
      .catch(() => setCategories([]))
      .finally(() => setLoading(false));
  }, []);

  const roots = categories.filter((c) => c.parent_id === null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
      <div className="border-b border-slate-200 pb-6 mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">دسته‌بندی‌های کالای خواب</h1>
        <p className="text-sm text-slate-500 mt-1.5">
          مجموعه کامل دسته‌بندی‌های اصلی و زیرشاخه‌های تخصصی فروشگاه کالای خواب رویای بیشتر
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array.from({length: 6}).map((_, i) => (
            <div key={i} className="h-48 rounded-xl bg-slate-100 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {roots.map((cat) => {
            const children = categories.filter((sub) => sub.parent_id === cat.id);
            return (
              <div
                key={cat.id}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col sm:flex-row hover:border-sky-200 transition-colors"
              >
                <div
                  onClick={() => onNavigate(`/catalog?categoryId=${cat.id}`)}
                  className="sm:w-44 h-44 sm:h-auto shrink-0 bg-sky-50 cursor-pointer overflow-hidden"
                >
                  <SafeImage
                    src={cat.image_url}
                    alt={cat.name}
                    fallbackTitle={cat.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <h2
                        onClick={() => onNavigate(`/catalog?categoryId=${cat.id}`)}
                        className="text-lg font-bold text-slate-900 hover:text-sky-700 cursor-pointer"
                      >
                        {cat.name}
                      </h2>
                      <span className="text-xs text-slate-500 tabular-nums shrink-0">
                        {formatNumberFa(cat.product_count ?? 0)} محصول
                      </span>
                    </div>
                    {cat.description && (
                      <p className="text-sm text-slate-600 leading-relaxed">{cat.description}</p>
                    )}

                    {children.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap gap-2">
                        {children.map((sub) => (
                          <button
                            key={sub.id}
                            type="button"
                            onClick={() => onNavigate(`/catalog?categoryId=${sub.id}`)}
                            className="px-2.5 py-1 text-xs font-medium text-sky-800 bg-sky-50 hover:bg-sky-100 rounded-md transition-colors cursor-pointer"
                          >
                            {sub.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <button
                      type="button"
                      onClick={() => onNavigate(`/catalog?categoryId=${cat.id}`)}
                      className="inline-flex items-center gap-1.5 text-sm font-semibold text-sky-700 hover:text-sky-900 cursor-pointer"
                    >
                      مشاهده محصولات این دسته
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
