import {useEffect, useState, type FormEvent} from 'react';
import {Search, SlidersHorizontal, X} from 'lucide-react';
import {apiRequest} from '../api/client';
import {ProductCard} from '../components/ProductCard';
import type {Brand, Category, ProductListItem} from '../types';
import {formatNumberFa} from '../utils/format';

interface CatalogPageProps {
  queryString: string;
  onNavigate: (path: string) => void;
}

export function CatalogPage({queryString, onNavigate}: CatalogPageProps) {
  const params = new URLSearchParams(queryString);

  const [q, setQ] = useState(params.get('q') || '');
  const [categoryId, setCategoryId] = useState(params.get('categoryId') || '');
  const [categorySlug, setCategorySlug] = useState(params.get('category') || '');
  const [brandId, setBrandId] = useState(params.get('brandId') || '');
  const [minPrice, setMinPrice] = useState(params.get('minPrice') || '');
  const [maxPrice, setMaxPrice] = useState(params.get('maxPrice') || '');
  const [stockStatus, setStockStatus] = useState(params.get('stockStatus') || '');
  const [feature, setFeature] = useState(params.get('feature') || '');
  const [featuredOnly, setFeaturedOnly] = useState(params.get('featured') === '1');
  const [sort, setSort] = useState(params.get('sort') || 'order');

  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [products, setProducts] = useState<ProductListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const p = new URLSearchParams(queryString);
    setQ(p.get('q') || '');
    setCategoryId(p.get('categoryId') || '');
    setCategorySlug(p.get('category') || '');
    setBrandId(p.get('brandId') || '');
    setMinPrice(p.get('minPrice') || '');
    setMaxPrice(p.get('maxPrice') || '');
    setStockStatus(p.get('stockStatus') || '');
    setFeature(p.get('feature') || '');
    setFeaturedOnly(p.get('featured') === '1');
    setSort(p.get('sort') || 'order');
  }, [queryString]);

  useEffect(() => {
    Promise.all([
      apiRequest<{categories: Category[]}>('/api/categories'),
      apiRequest<{brands: Brand[]}>('/api/brands'),
    ])
      .then(([catRes, brandRes]) => {
        setCategories(catRes.categories);
        setBrands(brandRes.brands);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);

    const apiParams = new URLSearchParams();
    if (q.trim()) apiParams.set('q', q.trim());
    if (categoryId) apiParams.set('categoryId', categoryId);
    else if (categorySlug) apiParams.set('category', categorySlug);
    if (brandId) apiParams.set('brandId', brandId);
    if (minPrice) apiParams.set('minPrice', minPrice);
    if (maxPrice) apiParams.set('maxPrice', maxPrice);
    if (stockStatus) apiParams.set('stockStatus', stockStatus);
    if (feature.trim()) apiParams.set('feature', feature.trim());
    if (featuredOnly) apiParams.set('featured', '1');
    if (sort) apiParams.set('sort', sort);

    apiRequest<{products: ProductListItem[]}>(`/api/products?${apiParams.toString()}`)
      .then((res) => {
        if (active) setProducts(res.products);
      })
      .catch(() => {
        if (active) setProducts([]);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [q, categoryId, categorySlug, brandId, minPrice, maxPrice, stockStatus, feature, featuredOnly, sort]);

  const clearAllFilters = () => {
    setQ('');
    setCategoryId('');
    setCategorySlug('');
    setBrandId('');
    setMinPrice('');
    setMaxPrice('');
    setStockStatus('');
    setFeature('');
    setFeaturedOnly(false);
    setSort('order');
    onNavigate('/catalog');
  };

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
  };

  const featureQuickPresets = ['مموری فوم', 'کتان', 'ارتوپدیک', 'ضدآب', 'فنر منفصل'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <div className="border-b border-slate-200 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">کاتالوگ محصولات کالای خواب</h1>
          <p className="text-sm text-slate-500 mt-1.5">
            جستجو و مقایسه دقیق بر اساس دسته‌بندی، برند، محدوده قیمت، جنس و ویژگی‌های فنی
          </p>
        </div>

        <form onSubmit={handleSearchSubmit} className="w-full md:w-80">
          <div className="flex items-center bg-white border border-slate-200 focus-within:border-sky-600 rounded-lg px-3 py-2">
            <Search className="w-4 h-4 text-slate-400 ml-2 shrink-0" />
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="نام محصول، برند یا کلمه کلیدی..."
              className="w-full text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
            />
            {q && (
              <button
                type="button"
                onClick={() => setQ('')}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label="پاک کردن جستجو"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </form>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Sidebar Filters */}
        <aside className="lg:col-span-3 bg-slate-50/70 border border-slate-200 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
              <SlidersHorizontal className="w-4 h-4 text-sky-700" />
              <span>فیلترهای پیشرفته</span>
            </div>
            <button
              type="button"
              onClick={clearAllFilters}
              className="text-xs font-medium text-sky-700 hover:text-sky-900 cursor-pointer"
            >
              پاک کردن همه
            </button>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">دسته‌بندی</label>
            <select
              value={categoryId}
              onChange={(e) => {
                setCategorySlug('');
                setCategoryId(e.target.value);
              }}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-sky-600"
            >
              <option value="">همه دسته‌بندی‌ها</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.parent_id ? `— ${cat.name}` : cat.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">برند تولیدکننده</label>
            <select
              value={brandId}
              onChange={(e) => setBrandId(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-sky-600"
            >
              <option value="">همه برندها</option>
              {brands.map((brand) => (
                <option key={brand.id} value={brand.id}>
                  {brand.name}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">محدوده قیمت (تومان)</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                min={0}
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                placeholder="حداقل"
                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs text-slate-800 tabular-nums focus:outline-none focus:border-sky-600"
              />
              <input
                type="number"
                min={0}
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                placeholder="حداکثر"
                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs text-slate-800 tabular-nums focus:outline-none focus:border-sky-600"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700">وضعیت موجودی</label>
            <select
              value={stockStatus}
              onChange={(e) => setStockStatus(e.target.value)}
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-sky-600"
            >
              <option value="">همه وضعیت‌ها</option>
              <option value="in_stock">موجود در انبار</option>
              <option value="low_stock">موجودی محدود</option>
              <option value="out_of_stock">ناموجود</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">ویژگی یا جنس محصول</label>
            <input
              type="text"
              value={feature}
              onChange={(e) => setFeature(e.target.value)}
              placeholder="مثال: کتان، مموری فوم..."
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-sky-600"
            />
            <div className="flex flex-wrap gap-1.5 pt-1">
              {featureQuickPresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setFeature(feature === preset ? '' : preset)}
                  className={`px-2.5 py-1 text-xs rounded-md border transition-colors cursor-pointer whitespace-nowrap ${
                    feature === preset
                      ? 'bg-sky-700 text-white border-sky-700'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-sky-300'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={featuredOnly}
              onChange={(e) => setFeaturedOnly(e.target.checked)}
              className="w-4 h-4 accent-sky-700 rounded"
            />
            <span>فقط محصولات منتخب و ویژه</span>
          </label>
        </aside>

        {/* Product Grid Area */}
        <div className="lg:col-span-9 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl px-4 py-3">
            <div className="text-sm text-slate-600 tabular-nums">
              نمایش <strong className="text-slate-900">{formatNumberFa(products.length)}</strong> محصول
            </div>
            <div className="flex items-center gap-2">
              <label htmlFor="catalog-sort" className="text-xs font-semibold text-slate-600 whitespace-nowrap">
                مرتب‌سازی:
              </label>
              <select
                id="catalog-sort"
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-sm text-slate-800 focus:outline-none focus:border-sky-600"
              >
                <option value="order">پیشنهاد فروشگاه</option>
                <option value="newest">جدیدترین</option>
                <option value="popular">پربازدیدترین</option>
                <option value="rating">بالاترین امتیاز</option>
                <option value="price_asc">ارزان‌ترین</option>
                <option value="price_desc">گران‌ترین</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({length: 6}).map((_, i) => (
                <div key={i} className="h-80 rounded-xl bg-slate-100 animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="bg-sky-50/40 border border-sky-100 rounded-xl p-10 text-center space-y-3">
              <p className="text-base font-bold text-slate-800">محصولی با این فیلترها یافت نشد.</p>
              <p className="text-sm text-slate-500">
                می‌توانید عبارت جستجو را تغییر دهید یا فیلترهای انتخابی را بازنشانی کنید.
              </p>
              <button
                type="button"
                onClick={clearAllFilters}
                className="px-5 py-2 bg-sky-700 hover:bg-sky-800 text-white text-sm font-semibold rounded-lg cursor-pointer"
              >
                نمایش همه محصولات
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
