export interface User {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  city: string | null;
  role_name: 'admin' | 'customer';
  role_display_name: string;
  is_blocked?: number;
  created_at?: string;
}

export interface Banner {
  id: number;
  title: string;
  subtitle: string | null;
  image_url: string;
  link_url: string | null;
  button_text: string | null;
  position: 'hero' | 'promo';
  sort_order: number;
  is_active: number;
}

export interface Category {
  id: number;
  parent_id: number | null;
  parent_name?: string | null;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  sort_order: number;
  is_active: number;
  product_count?: number;
}

export interface Brand {
  id: number;
  name: string;
  slug: string;
  country: string | null;
  description: string | null;
  product_count?: number;
}

export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock';

export interface ProductListItem {
  id: number;
  category_id: number;
  brand_id: number | null;
  name: string;
  slug: string;
  sku: string | null;
  short_description: string | null;
  dimensions: string | null;
  material: string | null;
  features: string | null;
  price: number;
  stock_status: StockStatus;
  stock_quantity: number;
  is_active: number;
  is_featured: number;
  sort_order: number;
  view_count: number;
  created_at: string;
  category_name: string;
  category_slug: string;
  brand_name: string | null;
  primary_image: string | null;
  avg_rating: number;
  rating_count: number;
  review_count: number;
}

export interface ProductImage {
  id: number;
  product_id: number;
  image_url: string;
  alt_text: string | null;
  is_primary: number;
  sort_order: number;
}

export interface ProductSpecification {
  id: number;
  product_id: number;
  spec_key: string;
  spec_value: string;
  sort_order: number;
}

export interface ProductDetail extends ProductListItem {
  description: string;
  category_parent_id: number | null;
  parent_category_name: string | null;
  brand_country: string | null;
  brand_description: string | null;
}

export interface RatingSummary {
  avg_rating: number;
  total_ratings: number;
  star_5: number;
  star_4: number;
  star_3: number;
  star_2: number;
  star_1: number;
}

export interface ReviewItem {
  id: number;
  product_id: number;
  user_id: number;
  title: string | null;
  comment: string;
  status: 'pending' | 'approved' | 'rejected';
  admin_note: string | null;
  helpful_count: number;
  created_at: string;
  updated_at: string;
  user_name?: string;
  user_email?: string;
  user_is_blocked?: number;
  user_rating?: number | null;
  user_voted_helpful?: number;
  product_name?: string;
  product_slug?: string;
  product_image?: string | null;
  my_rating?: number | null;
}
