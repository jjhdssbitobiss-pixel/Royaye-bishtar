import {useCallback, useEffect, useState} from 'react';
import {Footer} from './components/Footer';
import {Header} from './components/Header';
import {AuthProvider} from './context/AuthContext';
import {AdminPage} from './pages/AdminPage';
import {AuthPage} from './pages/AuthPage';
import {CatalogPage} from './pages/CatalogPage';
import {CategoriesPage} from './pages/CategoriesPage';
import {HomePage} from './pages/HomePage';
import {ProductDetailPage} from './pages/ProductDetailPage';
import {ProfilePage} from './pages/ProfilePage';

function AppRouter() {
  const [locationUrl, setLocationUrl] = useState(
    () => window.location.pathname + window.location.search
  );

  useEffect(() => {
    const onPopState = () => {
      setLocationUrl(window.location.pathname + window.location.search);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = useCallback((path: string) => {
    const target = path.startsWith('/') ? path : `/${path}`;
    window.history.pushState(null, '', target);
    setLocationUrl(target);
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, []);

  const [pathname, queryString = ''] = locationUrl.split('?');

  let content = <HomePage onNavigate={navigate} />;
  if (pathname === '/catalog') {
    content = <CatalogPage queryString={queryString} onNavigate={navigate} />;
  } else if (pathname === '/categories') {
    content = <CategoriesPage onNavigate={navigate} />;
  } else if (pathname.startsWith('/product/')) {
    const productId = pathname.replace('/product/', '').split('/')[0];
    content = <ProductDetailPage productId={productId} onNavigate={navigate} />;
  } else if (pathname === '/auth') {
    content = <AuthPage onNavigate={navigate} />;
  } else if (pathname === '/profile') {
    content = <ProfilePage onNavigate={navigate} />;
  } else if (pathname === '/admin') {
    content = <AdminPage onNavigate={navigate} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      <Header currentPath={pathname} onNavigate={navigate} />
      <div className="flex-1">{content}</div>
      <Footer onNavigate={navigate} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}
