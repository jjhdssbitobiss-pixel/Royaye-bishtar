const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => PERSIAN_DIGITS[Number(d)] ?? d);
}

export function formatPriceToman(price: number): string {
  const formatted = new Intl.NumberFormat('fa-IR').format(Math.round(price));
  return `${formatted} تومان`;
}

export function formatNumberFa(num: number): string {
  return new Intl.NumberFormat('fa-IR').format(num);
}

export function formatDateFa(isoDate: string): string {
  if (!isoDate) return '';
  const normalized = isoDate.includes('T') ? isoDate : isoDate.replace(' ', 'T') + 'Z';
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return isoDate;
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(d);
}

export function getStockLabel(status: string): {text: string; tone: 'emerald' | 'amber' | 'rose'} {
  switch (status) {
    case 'in_stock':
      return {text: 'موجود در انبار', tone: 'emerald'};
    case 'low_stock':
      return {text: 'موجودی محدود', tone: 'amber'};
    case 'out_of_stock':
      return {text: 'ناموجود', tone: 'rose'};
    default:
      return {text: 'نامشخص', tone: 'amber'};
  }
}

export function getReviewStatusLabel(status: string): {text: string; tone: 'emerald' | 'amber' | 'rose'} {
  switch (status) {
    case 'approved':
      return {text: 'تایید شده', tone: 'emerald'};
    case 'rejected':
      return {text: 'تایید نشده', tone: 'rose'};
    default:
      return {text: 'در انتظار بررسی', tone: 'amber'};
  }
}
