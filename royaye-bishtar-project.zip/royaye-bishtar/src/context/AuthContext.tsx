import {createContext, useCallback, useContext, useEffect, useState, type ReactNode} from 'react';
import {apiRequest, setApiToken} from '../api/client';
import type {User} from '../types';

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  needsAdminSetup: boolean;
  checkingSetup: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (payload: {
    full_name: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
  }) => Promise<User>;
  setupAdmin: (payload: {full_name: string; email: string; password: string}) => Promise<User>;
  updateProfile: (payload: {
    full_name: string;
    phone?: string;
    city?: string;
    current_password?: string;
    new_password?: string;
  }) => Promise<User>;
  logout: () => void;
  refreshAdminStatus: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({children}: {children: ReactNode}) {
  const [user, setUser] = useState<User | null>(null);
  const [needsAdminSetup, setNeedsAdminSetup] = useState(false);
  const [checkingSetup, setCheckingSetup] = useState(true);

  const refreshAdminStatus = useCallback(async () => {
    try {
      const res = await apiRequest<{needsAdminSetup: boolean}>('/api/auth/admin-status');
      setNeedsAdminSetup(res.needsAdminSetup);
    } catch {
      setNeedsAdminSetup(false);
    } finally {
      setCheckingSetup(false);
    }
  }, []);

  useEffect(() => {
    refreshAdminStatus();
  }, [refreshAdminStatus]);

  const login = useCallback(async (email: string, password: string) => {
    const res = await apiRequest<{token: string; user: User}>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({email, password}),
    });
    setApiToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  const register = useCallback(
    async (payload: {
      full_name: string;
      email: string;
      password: string;
      phone?: string;
      city?: string;
    }) => {
      const res = await apiRequest<{token: string; user: User}>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setApiToken(res.token);
      setUser(res.user);
      return res.user;
    },
    []
  );

  const setupAdmin = useCallback(
    async (payload: {full_name: string; email: string; password: string}) => {
      const res = await apiRequest<{token: string; user: User}>('/api/auth/setup-admin', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setApiToken(res.token);
      setUser(res.user);
      setNeedsAdminSetup(false);
      return res.user;
    },
    []
  );

  const updateProfile = useCallback(
    async (payload: {
      full_name: string;
      phone?: string;
      city?: string;
      current_password?: string;
      new_password?: string;
    }) => {
      const res = await apiRequest<{user: User}>('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      setUser(res.user);
      return res.user;
    },
    []
  );

  const logout = useCallback(() => {
    setApiToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: Boolean(user),
        isAdmin: user?.role_name === 'admin',
        needsAdminSetup,
        checkingSetup,
        login,
        register,
        setupAdmin,
        updateProfile,
        logout,
        refreshAdminStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
