import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import 'dotenv/config';
import {initDatabase, UPLOADS_DIR} from './server/db.ts';
import {adminRouter} from './server/routes/admin.ts';
import {authRouter} from './server/routes/auth.ts';
import {catalogRouter} from './server/routes/catalog.ts';

initDatabase();

const app = express();
const PORT = 3000;

app.use(express.json({limit: '8mb'}));

// Serve uploaded product & banner images safely
app.use(
  '/uploads',
  express.static(UPLOADS_DIR, {
    setHeaders: (res) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
    },
  })
);

// Direct download route for the packaged project archive
app.get('/royaye-bishtar-project.zip', (_req, res) => {
  const archivePath = path.resolve(process.cwd(), 'royaye-bishtar-project.zip');
  if (!fs.existsSync(archivePath)) {
    res.status(404).json({error: 'فایل فشرده پروژه یافت نشد.'});
    return;
  }
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.download(archivePath, 'royaye-bishtar-project.zip');
});

// API routes
app.use('/api/auth', authRouter);
app.use('/api', catalogRouter);
app.use('/api/admin', adminRouter);

// Health endpoint
app.get('/api/health', (_req, res) => {
  res.json({status: 'ok'});
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Royaye Bishtar Sleep Catalog server running on http://0.0.0.0:${PORT}`);
  });

  const shutdown = async () => {
    server.close(async () => {
      try {
        const {db} = await import('./server/db.ts');
        db.close();
      } catch {
        // ignore
      }
      process.exit(0);
    });
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

startServer();
